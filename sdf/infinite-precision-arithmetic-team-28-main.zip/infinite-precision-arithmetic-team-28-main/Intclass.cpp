#include "Integer.h"
#include<iostream>
#include<stdio.h>
#include<string>
#include<vector>
#include<algorithm>
using namespace std;
using namespace InfiniteArithmetic;
int A=0;                       //variable to validate signs of given input.
Integer::Integer()
{
	s = "0";                  //default constructor string initialisation to zero.
}
Integer::Integer(string a)
{
	s = a;                    //parameterised constructor.
}
Integer::Integer( Integer &b)
{
	s = b.s;                  //Copy constructor.
}
Integer::~Integer()
{                             //default destructor.
}
void Integer::sum(string s1,string s2)
{
	string min = s1;
	string max = s2;
	if(s1.size() > s2.size()) {
		min = s2;
		max = s1;
	}
	else if(s2.size() > s1.size()){
		min = s1;
		max = s2;
	}
	vector<int>s3;
	int p=0;
	int q=0;
	if(A==4){
		long long int  k = max.size()-1;
		long long int  i = min.size()-1;
		for(;i>=0;i--){
			p = (max[k]-'0') + (min[i]-'0');
			if(q!=0){
				p=p+1;
				q=0;
			}
			if(p>=10){
				q=1;
				s3.push_back(p-10);
			}
			else if(p<10){
				s3.push_back(p);
			}
			k=k-1;
		}
		if(k==-1){
			s3.push_back(q);
		}
		else if(k!=-1){
			for(;k>=0;k--){
				int h=(max[k]-'0')+q;
				if(h<10){
					s3.push_back(h);
					q=0;
				}
				else if(h>=10){
					q=1;
					s3.push_back(h-10);
				}
			}
			if(q!=0) s3.push_back(q);
		}
		reverse(s3.begin(),s3.end());
		for(int l:s3){
			cout<< l;
		}
	}
	else if(A==1){
		long long int  k = max.size()-1;
		long long int  i = min.size()-1;
		for(;i>=1;i--){
			p = (max[k]-'0') + (min[i]-'0');
			if(q!=0){
				p=p+1;
				q=0;
			}
			if(p>=10){
				q=1;
				s3.push_back(p-10);
			}
			else if(p<10){
				s3.push_back(p);
			}
			k=k-1;
		}
		if(k==0){
			s3.push_back(q);
		}
		else if(k!=0){
			for(;k>=1;k--){
				int h=(max[k]-'0')+q;
				if(h<10){
					s3.push_back(h);
					q=0;
				}
				else if(h>=10){
					q=1;
					s3.push_back(h-10);
				}
			}
			if(q!=0) s3.push_back(q);
		}
		reverse(s3.begin(),s3.end());
		cout<<"-";
		for(int l:s3){
			cout<< l;
		}
	}
	else if(A==6){
		string lmax;
		string lmin;    
		min=s1;
		max=s2;
		if(s1.length()>s2.length()){
			lmax=s1;
			lmin=s2;
		}
		else if(s2.length()>=s1.length()){
			lmax=s2;
			lmin=s1;
		}
		if(lmax!=max){
			long long int  k = lmax.size()-1;
			long long int  i = lmin.size()-1;
			for(;i>=0;i--){
				p = (lmax[k]-'0') + (lmin[i]-'0');
				if(q!=0){
					p=p+1;
					q=0;
				}
				if(p>=10){
					q=1;
					s3.push_back(p-10);
				}
				else if(p<10){
					s3.push_back(p);
				}
				k=k-1;
			}
			if(k==0){
				s3.push_back(q);
			}
			else if(k!=0){
				for(;k>=1;k--){
					int h=(lmax[k]-'0')+q;
					if(h<10){
						s3.push_back(h);
						q=0;
					}
					else if(h>=10){
						q=1;
						s3.push_back(h-10);
					}
				}
				if(q!=0) s3.push_back(q);
			}
			reverse(s3.begin(),s3.end());
			cout<<"-";
			for(int l:s3){
				cout<< l;
			}
		}
		else if(lmax==max){
			long long int  k = max.size()-1;
			long long int  i = min.size()-1;
			for(;i>0;i--){
				p = (max[k]-'0') + (min[i]-'0');
				if(q!=0){
					p=p+1;
					q=0;
				}
				if(p>=10){
					q=1;
					s3.push_back(p-10);
				}
				else if(p<10){
					s3.push_back(p);
				}
				k=k-1;
			}
			if(k==-1){
				s3.push_back(q);
			}
			else if(k!=-1){
				for(;k>=0;k--){
					int h=(max[k]-'0')+q;
					if(h<10){
						s3.push_back(h);
						q=0;
					}
					else if(h>=10){
						q=1;
						s3.push_back(h-10);
					}
				}
				if(q!=0) s3.push_back(q);
			}
			reverse(s3.begin(),s3.end());
			cout<<"-";
			for(int l:s3){
				cout<< l;
			}
		}
	}
	else if(A==7){
		string lmax;
		string lmin;
		min=s2;
		max=s1;
		if(s1.size()>=s2.size()){
			lmax=s1;
			lmin = s2;	
		} 
		else if(s2.size()>s1.size()){
			lmax=s2;
			lmin=s1;
		}
		if(lmax!=max){
			long long int  k = lmax.size()-1;
			long long int  i = lmin.size()-1;
			for(;i>=0;i--){
				p = (lmax[k]-'0') + (lmin[i]-'0');
				if(q!=0){
					p=p+1;
					q=0;
				}
				if(p>=10){
					q=1;
					s3.push_back(p-10);
				}
				else if(p<10){
					s3.push_back(p);
				}
				k=k-1;
			}
			if(k==0){
				s3.push_back(q);
			}
			else if(k!=0){
				for(;k>=1;k--){
					int h=(lmax[k]-'0')+q;
					if(h<10){
						s3.push_back(h);
						q=0;
					}
					else if(h>=10){
						q=1;
						s3.push_back(h-10);
					}
				}
				if(q!=0) s3.push_back(q);
			}
			reverse(s3.begin(),s3.end());
			for(int l:s3){
				cout<< l;
			}
		}
		else if(lmax==max){
			long long int  k = max.size()-1;
			long long int  i = min.size()-1;
			for(;i>0;i--){
				p = (max[k]-'0') + (min[i]-'0');
				if(q!=0){
					p=p+1;
					q=0;
				}
				if(p>=10){
					q=1;
					s3.push_back(p-10);
				}
				else if(p<10){
					s3.push_back(p);
				}
				k=k-1;
			}
			if(k==-1){
				s3.push_back(q);
			}
			else if(k!=-1){
				for(;k>=0;k--){
					int h=(max[k]-'0')+q;
					if(h<10){
						s3.push_back(h);
						q=0;
					}
					else if(h>=10){
						q=1;
						s3.push_back(h-10);
					}
				}
				if(q!=0) s3.push_back(q);
			}
			reverse(s3.begin(),s3.end());
			for(int l:s3){
				cout<< l;
			}
		}
	}
	cout<<endl;
}
void Integer::diff(string s1,string s2){
	string min = s2;
	string max = s1;
	int f1 = 0;
	int f2 = 0;
	if(A==8){
		if(s1.size() == s2.size()){
			for(int r=0;r<s1.size();r++){
				f1 = s1[r] - '0';
				f2 = s2[r] - '0';
				if(f1>f2){
					max = s1;
					min = s2;
					break;
				}
				else if(f1<f2){
					min = s1;
					max = s2;
					break;
				}
			}	
		}
		else if(s1.size() > s2.size()) {
			min =s2;
			max =s1;
		}
		else if(s2.size() > s1.size()){
			min =s1;
			max =s2;
		}
		vector<int>s3;
		int p=0;
		int q=0;
		int  k = max.size()-1;
		int  i = min.size()-1;
		for(;i>=0;i--){
			p = (max[k]-'0') - (min[i]-'0');
			if(q!=0){
				p = p-1;
				q = 0;
			}
			if((max[k]-'0')>(min[i]-'0')){
				s3.push_back(p);
			}
			else if((max[k]-'0')<(min[i]-'0')){
				p = 10 + p;
				q = -1;
				s3.push_back(p);
			}
			else if((max[k]-'0')==(min[i]-'0')){
				if(p!=((max[k]-'0')-(min[i]-'0'))){
					p = 10 + p;
					s3.push_back(p);
					q=-1;
				}
				else{
					s3.push_back(p);
				}
			}
			k = k-1;
		}
		if(k!=i){
			s3.push_back((max[k]-'0')+q);
			for(int y=k-1;y>=0;y--){
				s3.push_back((max[y]-'0'));
			}
		}
		reverse(s3.begin(),s3.end());
		if(s2==max) cout<<"-";
		for(int l:s3){
			cout<<l;
		}
	}
	else if(A==5){
		if(s1.size() == s2.size()){
			for(int r=0;r<s1.size();r++){
				f1 = s1[r] - '0';
				f2 = s2[r] - '0';
				if(f1>f2){
					max = s1;
					min = s2;
					break;
				}
				else if(f1<f2){
					min = s1;
					max = s2;
					break;
				}
			}	
		}
		else if(s1.size() > s2.size()) {
			min =s2;
			max =s1;
		}
		else if(s2.size() > s1.size()){
			min =s1;
			max =s2;
		}
		vector<int>s3;
		int p=0;
		int q=0;
		int  k = max.size()-1;
		int  i = min.size()-1;
		for(;i>=1;i--){
			p = (max[k]-'0') - (min[i]-'0');
			if(q!=0){
				p = p-1;
				q = 0;
			}
			if((max[k]-'0')>(min[i]-'0')){
				s3.push_back(p);
			}
			else if((max[k]-'0')<(min[i]-'0')){
				p = 10 + p;
				q = -1;
				s3.push_back(p);
			}
			else if((max[k]-'0')==(min[i]-'0')){
				if(p!=((max[k]-'0')-(min[i]-'0'))){
					p = 10 + p;
					s3.push_back(p);
					q=-1;
				}
				else{
					s3.push_back(p);
				}
			}
			k = k-1;
		}
		if(k!=i){
			s3.push_back((max[k]-'0')+q);
			for(int y=k-1;y>=1;y--){
				s3.push_back((max[y]-'0'));
			}
		}
		reverse(s3.begin(),s3.end());
		if(s1==max) cout<<"-";
		for(int l:s3){
			cout<<l;
		}
	}
	else if(A==3){
		string lmax;
		string lmin;
		int f=0;
		max=s1;
		min=s2;
		if(s2.size()-1>s1.size()){
			lmax=s2;
			lmin=s1;
		}
		else if(s2.size()-1==s1.size()){
			for(int r=0;r<s1.size();r++){
				f1 = s1[r] - '0';
				f2 = s2[r+1] - '0';
				if(f2>f1){
					vector<int>s3;
					int p=0;
					int q=0;
					int  k = s2.size()-1;
					int  i = s1.size()-1;
					for(;i>=0;i--){
						p = (s2[k]-'0') - (s1[i]-'0');
						if(q!=0){
							p = p-1;
							q = 0;
						}
						if((s2[k]-'0')>(s1[i]-'0')){
							s3.push_back(p);
						}
						else if((s2[k]-'0')<(s1[i]-'0')){
							p = 10 + p;
							q = -1;
							s3.push_back(p);
						}
						else if((s2[k]-'0')==(s1[i]-'0')){
							if(p!=((s2[k]-'0')-(s1[i]-'0'))){
								p = 10 + p;
								s3.push_back(p);
								q=-1;
							}
							else{
								s3.push_back(p);
							}
						}
						k = k-1;
					}
					reverse(s3.begin(),s3.end());
					cout<<"-";
					for(int l:s3){
						cout<<l;
					}
					f=1;
					break;
				}
				else if(f2<f1){
					lmax=s1;
					lmin=s2;
					min = s2;
					max = s1;
					break;
				}
			}	
		}
		else if(s1.size()>s2.size()-1){
			lmax=s1;
			lmin=s2;
		}
		if(lmax==max){
			vector<int>s3;
			int p=0;
			int q=0;
			int  k = max.size()-1;
			int  i = min.size()-1;
			for(;i>=1;i--){
				p = (max[k]-'0') - (min[i]-'0');
				if(q!=0){
					p = p-1;
					q = 0;
				}
				if((max[k]-'0')>(min[i]-'0')){
					s3.push_back(p);
				}
				else if((max[k]-'0')<(min[i]-'0')){
					p = 10 + p;
					q = -1;
					s3.push_back(p);
				}
				else if((max[k]-'0')==(min[i]-'0')){
					if(p!=((max[k]-'0')-(min[i]-'0'))){
						p = 10 + p;
						s3.push_back(p);
						q=-1;
					}
					else{
						s3.push_back(p);
					}
				}
				k = k-1;
			}
			if(k!=-1){
				s3.push_back((max[k]-'0')+q);
				for(int y=k-1;y>=0;y--){
					s3.push_back((max[y]-'0'));
				}
			}
			reverse(s3.begin(),s3.end());
			for(int l:s3){
				cout<<l;
			}
		}
		else if(lmax!=max && f!=1){
			vector<int>s3;
			int p=0;
			int q=0;
			int  k = lmax.size()-1;
			int  i = lmin.size()-1;
			for(;i>=0;i--){
				p = (lmax[k]-'0') - (lmin[i]-'0');
				if(q!=0){
					p = p-1;
					q = 0;
				}
				if((lmax[k]-'0')>(lmin[i]-'0')){
					s3.push_back(p);
				}
				else if((lmax[k]-'0')<(lmin[i]-'0')){
					p = 10 + p;
					q = -1;
					s3.push_back(p);
				}
				else if((lmax[k]-'0')==(lmin[i]-'0')){
					if(p!=((lmax[k]-'0')-(lmin[i]-'0'))){
						p = 10 + p;
						s3.push_back(p);
						q=-1;
					}
					else{
						s3.push_back(p);
					}
				}
				k = k-1;
			}
			if(k!=i){
				s3.push_back((lmax[k]-'0')+q);
				for(int y=k-1;y>=1;y--){
					s3.push_back((lmax[y]-'0'));
				}
			}
			reverse(s3.begin(),s3.end());
			cout<<"-";
			for(int l:s3){
				cout<<l;
			}
		}
	}
	else if(A==2){
		string lmax;
		string lmin;
		int f=0;
		max=s2;
		min=s1;
		if(s1.size()-1>s2.size()){
			lmax=s1;
			lmin=s2;
		}
		else if(s1.size()-1==s2.size()){
			for(int r=0;r<s2.size();r++){
				f1 = s1[r+1] - '0';
				f2 = s2[r] - '0';
				if(f1>f2){
					vector<int>s3;
					int p=0;
					int q=0;
					int  k = s1.size()-1;
					int  i = s2.size()-1;
					for(;i>=0;i--){
						p = (s1[k]-'0') - (s2[i]-'0');
						if(q!=0){
							p = p-1;
							q = 0;
						}
						if((s1[k]-'0')>(s2[i]-'0')){
							s3.push_back(p);
						}
						else if((s1[k]-'0')<(s2[i]-'0')){
							p = 10 + p;
							q = -1;
							s3.push_back(p);
						}
						else if((s1[k]-'0')==(s2[i]-'0')){
							if(p!=((s1[k]-'0')-(s2[i]-'0'))){
								p = 10 + p;
								s3.push_back(p);
								q=-1;
							}
							else{
								s3.push_back(p);
							}
						}
						k = k-1;
					}
					reverse(s3.begin(),s3.end());
					cout<<"-";
					for(int l:s3){
						cout<<l;
					}
					f=1;
					break;
				}
				else if(f1<f2){
					lmax=s2;
					lmin=s1;
					min = s1;
					max = s2;
					break;
				}
			}	
		}
		else if(s2.size()>s1.size()-1){
			lmax=s2;
			lmin=s1;
		}
		if(lmax==max){
			vector<int>s3;
			int p=0;
			int q=0;
			int  k = max.size()-1;
			int  i = min.size()-1;
			for(;i>=1;i--){
				p = (max[k]-'0') - (min[i]-'0');
				if(q!=0){
					p = p-1;
					q = 0;
				}
				if((max[k]-'0')>(min[i]-'0')){
					s3.push_back(p);
				}
				else if((max[k]-'0')<(min[i]-'0')){
					p = 10 + p;
					q = -1;
					s3.push_back(p);
				}
				else if((max[k]-'0')==(min[i]-'0')){
					if(p!=((max[k]-'0')-(min[i]-'0'))){
						p = 10 + p;
						s3.push_back(p);
						q=-1;
					}
					else{
						s3.push_back(p);
					}
				}
				k = k-1;
			}
			if(k!=-1){
				s3.push_back((max[k]-'0')+q);
				for(int y=k-1;y>=0;y--){
					s3.push_back((max[y]-'0'));
				}
			}
			reverse(s3.begin(),s3.end());
			for(int l:s3){
				cout<<l;
			}
		}
		else if(lmax!=max && f!=1){
			vector<int>s3;
			int p=0;
			int q=0;
			int  k = lmax.size()-1;
			int  i = lmin.size()-1;
			for(;i>=0;i--){
				p = (lmax[k]-'0') - (lmin[i]-'0');
				if(q!=0){
					p = p-1;
					q = 0;
				}
				if((lmax[k]-'0')>(lmin[i]-'0')){
					s3.push_back(p);
				}
				else if((lmax[k]-'0')<(lmin[i]-'0')){
					p = 10 + p;
					q = -1;
					s3.push_back(p);
				}
				else if((lmax[k]-'0')==(lmin[i]-'0')){
					if(p!=((lmax[k]-'0')-(lmin[i]-'0'))){
						p = 10 + p;
						s3.push_back(p);
						q=-1;
					}
					else{
						s3.push_back(p);
					}
				}
				k = k-1;
			}
			if(k!=i){
				s3.push_back((lmax[k]-'0')+q);
				for(int y=k-1;y>=1;y--){
					s3.push_back((lmax[y]-'0'));
				}
			}
			reverse(s3.begin(),s3.end());
			cout<<"-";
			for(int l:s3){
				cout<<l;
			}
		}
	}
	cout<<endl;
}

void Integer::operator+(const Integer &t)
{
	if( s[0] == '-' && t.s[0] == '-'){
		A=1;
		Integer::sum(s,t.s);
	}
	else if( s[0] == '-' && t.s[0] != '-'){
		A=2;
		Integer::diff(s,t.s);
	}
	else if( s[0] != '-' && t.s[0] == '-'){
		A=3;
		Integer::diff(s,t.s);
	}
	else if( s[0] != '-' && t.s[0] != '-'){
		A=4;
		Integer::sum(s,t.s);
	}
}
void  Integer::operator-(const Integer &t)
{	
	if( s[0] == '-' && t.s[0] == '-'){
		A=5;
		Integer::diff(s,t.s);
	}
	else if( s[0] == '-' && t.s[0] != '-'){
		A=6;
		Integer::sum(s,t.s);
	}
	else if( s[0] != '-' && t.s[0] == '-'){
		A=7;
		Integer::sum(s,t.s);
	}
	else if( s[0] != '-' && t.s[0] != '-'){
		A=8;
		Integer::diff(s,t.s);
	}
}

