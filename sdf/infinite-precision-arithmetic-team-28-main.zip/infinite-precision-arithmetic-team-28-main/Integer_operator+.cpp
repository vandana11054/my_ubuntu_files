void Integer::operator+(const Integer &t)
{
        if( s[0] == '-' && t.s[0] == '-'){
                A=1;
                Integer::sum(s,t.s);
        }
        else if( s[0] == '-' && t.s[0] != '-'){
                A=2;
                Integer::diff(s,t.s);
        }
        else if( s[0] != '-' && t.s[0] == '-'){
                A=3;
                Integer::diff(s,t.s);
        }
        else if( s[0] != '-' && t.s[0] != '-'){
                A=4;
                Integer::sum(s,t.s);
        }
}