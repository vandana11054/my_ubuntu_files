

#pragma once
#include<iostream>
#include<string>
using namespace std;
namespace InfiniteArithmetic{
        class Float
        {
                private:
                        string s;
                public:
                        Float();
                        Float(string);
                        Float(Float&);
                        ~Float();
                        void sum(string,string);
                        void operator+(const Float&);
        };
}

