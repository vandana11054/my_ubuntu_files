void Integer::sum(string s1,string s2)
{
	string min = s1;
	string max = s2;
	if(s1.size() > s2.size()) {
		min = s2;
		max = s1;
	}
	else if(s2.size() > s1.size()){
		min = s1;
		max = s2;
	}
	vector<int>s3;
	int p=0;
	int q=0;
	if(A==4){
		long long int  k = max.size()-1;
		long long int  i = min.size()-1;
		for(;i>=0;i--){
			p = (max[k]-'0') + (min[i]-'0');
			if(q!=0){
				p=p+1;
				q=0;
			}
			if(p>=10){
				q=1;
				s3.push_back(p-10);
			}
			else if(p<10){
				s3.push_back(p);
			}
			k=k-1;
		}
		if(k==-1){
			s3.push_back(q);
		}
		else if(k!=-1){
			for(;k>=0;k--){
				int h=(max[k]-'0')+q;
				if(h<10){
					s3.push_back(h);
					q=0;
				}
				else if(h>=10){
					q=1;
					s3.push_back(h-10);
				}
			}
			if(q!=0) s3.push_back(q);
		}
		reverse(s3.begin(),s3.end());
		for(int l:s3){
			cout<< l;
		}
	}
	else if(A==1){
		long long int  k = max.size()-1;
		long long int  i = min.size()-1;
		for(;i>=1;i--){
			p = (max[k]-'0') + (min[i]-'0');
			if(q!=0){
				p=p+1;
				q=0;
			}
			if(p>=10){
				q=1;
				s3.push_back(p-10);
			}
			else if(p<10){
				s3.push_back(p);
			}
			k=k-1;
		}
		if(k==0){
			s3.push_back(q);
		}
		else if(k!=0){
			for(;k>=1;k--){
				int h=(max[k]-'0')+q;
				if(h<10){
					s3.push_back(h);
					q=0;
				}
				else if(h>=10){
					q=1;
					s3.push_back(h-10);
				}
			}
			if(q!=0) s3.push_back(q);
		}
		reverse(s3.begin(),s3.end());
		cout<<"-";
		for(int l:s3){
			cout<< l;
		}
	}
	else if(A==6){
		string lmax;
		string lmin;    
		min=s1;
		max=s2;
		if(s1.length()>s2.length()){
			lmax=s1;
			lmin=s2;
		}
		else if(s2.length()>=s1.length()){
			lmax=s2;
			lmin=s1;
		}
		if(lmax!=max){
			long long int  k = lmax.size()-1;
			long long int  i = lmin.size()-1;
			for(;i>=0;i--){
				p = (lmax[k]-'0') + (lmin[i]-'0');
				if(q!=0){
					p=p+1;
					q=0;
				}
				if(p>=10){
					q=1;
					s3.push_back(p-10);
				}
				else if(p<10){
					s3.push_back(p);
				}
				k=k-1;
			}
			if(k==0){
				s3.push_back(q);
			}
			else if(k!=0){
				for(;k>=1;k--){
					int h=(lmax[k]-'0')+q;
					if(h<10){
						s3.push_back(h);
						q=0;
					}
					else if(h>=10){
						q=1;
						s3.push_back(h-10);
					}
				}
				if(q!=0) s3.push_back(q);
			}
			reverse(s3.begin(),s3.end());
			cout<<"-";
			for(int l:s3){
				cout<< l;
			}
		}
		else if(lmax==max){
			long long int  k = max.size()-1;
			long long int  i = min.size()-1;
			for(;i>0;i--){
				p = (max[k]-'0') + (min[i]-'0');
				if(q!=0){
					p=p+1;
					q=0;
				}
				if(p>=10){
					q=1;
					s3.push_back(p-10);
				}
				else if(p<10){
					s3.push_back(p);
				}
				k=k-1;
			}
			if(k==-1){
				s3.push_back(q);
			}
			else if(k!=-1){
				for(;k>=0;k--){
					int h=(max[k]-'0')+q;
					if(h<10){
						s3.push_back(h);
						q=0;
					}
					else if(h>=10){
						q=1;
						s3.push_back(h-10);
					}
				}
				if(q!=0) s3.push_back(q);
			}
			reverse(s3.begin(),s3.end());
			cout<<"-";
			for(int l:s3){
				cout<< l;
			}
		}
	}
	else if(A==7){
		string lmax;
		string lmin;
		min=s2;
		max=s1;
		if(s1.size()>=s2.size()){
			lmax=s1;
			lmin = s2;	
		} 
		else if(s2.size()>s1.size()){
			lmax=s2;
			lmin=s1;
		}
		if(lmax!=max){
			long long int  k = lmax.size()-1;
			long long int  i = lmin.size()-1;
			for(;i>=0;i--){
				p = (lmax[k]-'0') + (lmin[i]-'0');
				if(q!=0){
					p=p+1;
					q=0;
				}
				if(p>=10){
					q=1;
					s3.push_back(p-10);
				}
				else if(p<10){
					s3.push_back(p);
				}
				k=k-1;
			}
			if(k==0){
				s3.push_back(q);
			}
			else if(k!=0){
				for(;k>=1;k--){
					int h=(lmax[k]-'0')+q;
					if(h<10){
						s3.push_back(h);
						q=0;
					}
					else if(h>=10){
						q=1;
						s3.push_back(h-10);
					}
				}
				if(q!=0) s3.push_back(q);
			}
			reverse(s3.begin(),s3.end());
			for(int l:s3){
				cout<< l;
			}
		}
		else if(lmax==max){
			long long int  k = max.size()-1;
			long long int  i = min.size()-1;
			for(;i>0;i--){
				p = (max[k]-'0') + (min[i]-'0');
				if(q!=0){
					p=p+1;
					q=0;
				}
				if(p>=10){
					q=1;
					s3.push_back(p-10);
				}
				else if(p<10){
					s3.push_back(p);
				}
				k=k-1;
			}
			if(k==-1){
				s3.push_back(q);
			}
			else if(k!=-1){
				for(;k>=0;k--){
					int h=(max[k]-'0')+q;
					if(h<10){
						s3.push_back(h);
						q=0;
					}
					else if(h>=10){
						q=1;
						s3.push_back(h-10);
					}
				}
				if(q!=0) s3.push_back(q);
			}
			reverse(s3.begin(),s3.end());
			for(int l:s3){
				cout<< l;
			}
		}
	}
	cout<<endl;
}
		
