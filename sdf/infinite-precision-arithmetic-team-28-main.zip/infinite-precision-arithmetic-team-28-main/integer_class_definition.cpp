#include "Integer.h"
#include<iostream>
#include<stdio.h>
#include<string>
#include<vector>
#include<algorithm>
using namespace std;
using namespace InfiniteArithmetic;
int A=0;                       //variable to validate signs of given input.
Integer::Integer()
{
	s = "0";                  //default constructor string initialisation to zero.
}
Integer::Integer(string a)
{
	s = a;                    //parameterised constructor.
}
Integer::Integer( Integer &b)
{
	s = b.s;                  //Copy constructor.
}
Integer::~Integer()
{                             //default destructor.
}