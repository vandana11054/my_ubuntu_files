

#include<iostream>
#include "Integer.h"
#include "Float.h"
using namespace std;
using namespace InfiniteArithmetic;

int main(int argc,char* argv[])
{
   string type = argv[1];
   if(argc>4 && type =="int"){
	string in = argv[2];
	Integer num1(argv[3]);
	Integer num2(argv[4]);
	if(in == "add"){
		num1.Integer::operator+(num2);
	}
	else if(in == "sub"){
                num1.Integer::operator-(num2);
        }
   }
   else if(argc>4 && type == "float"){
       string in =argv[2];
       Float num1(argv[3]);
       Float num2(argv[4]);
       if(in == "add"){
              num1.Float::operator+(num2);
       }
       else{
	       cout<<"Given arithmetic operation for float is not provided in the library"<<endl;
       }
   }
   else{
	cout<<"Insufficient arguments for provided binary arithmetic operation."<<endl;
   }
   return 0;
}

