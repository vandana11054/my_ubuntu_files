
void  Integer::operator-(const Integer &t)
{	
	if( s[0] == '-' && t.s[0] == '-'){
		A=5;
		Integer::diff(s,t.s);
	}
	else if( s[0] == '-' && t.s[0] != '-'){
		A=6;
		Integer::sum(s,t.s);
	}
	else if( s[0] != '-' && t.s[0] == '-'){
		A=7;
		Integer::sum(s,t.s);
	}
	else if( s[0] != '-' && t.s[0] != '-'){
		A=8;
		Integer::diff(s,t.s);
	}
}

