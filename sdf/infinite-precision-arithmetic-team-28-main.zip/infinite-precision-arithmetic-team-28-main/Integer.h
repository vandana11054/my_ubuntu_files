

#pragma once
#include<iostream>
#include<string>
using namespace std;
namespace InfiniteArithmetic{
	class Integer
	{
		private:
			string s;
		public:
			Integer();
			Integer(string);
			Integer(Integer&);  
			~Integer();
			void sum(string,string);
			void diff(string,string);
			void operator+(const Integer&);
			void operator-(const Integer&);
	};
}
