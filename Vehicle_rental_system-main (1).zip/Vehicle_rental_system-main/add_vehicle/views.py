from django.shortcuts import render, redirect
import mysql.connector as sql
# Create your views here.
def addvhcl(request):
    global veh_ty,veh_mo,rent,regNo,veh_cond,last_serv
    if request.method == 'POST':
        cinst = sql.connect(host = 'localhost',user='root',passwd = '8675@Tjc2023',database = 'vehicle_rental_db')
        ccursor = cinst.cursor()
        val = request.POST
        for key,value in val.items():
            if key == "veh_type":
                veh_ty = value
            elif key == "model":
                veh_mo = value
            elif key == "price":
                rent = value
            elif key == "regNo":
                regNo = value
            elif key == "last_serv":
                last_serv = value
        try:
            
            if veh_ty=="Two-Wheeler":
                veh_ty="2 Wheeler"
            else:
                veh_ty="4 Wheeler"
            ccursor.callproc("insert_vehicle", [veh_ty, veh_mo, rent, regNo, "Good", last_serv, "available"]) #using the stored procedure insert_vehicle to insert an entry into the vehicle_details
            cinst.commit()
        except Exception as e:
            print(e)
            return render(request,"database_error.html")
        return redirect('http://127.0.0.1:8000/add_vehicle/')
    return render(request,'add_vehicle.html')