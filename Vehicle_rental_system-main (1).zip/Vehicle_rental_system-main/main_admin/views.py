from django.shortcuts import render

# Create your views here.
def manage_admin(request):
    return render(request,"admin_page.html")