from django.shortcuts import render
import mysql.connector as sql
# Create your views here.
def staff(request):
    connection = sql.connect(
        host='localhost',
        user='root',
        password='8675@Tjc2023',
        database='vehicle_rental_db'
    )
    
    cursor = connection.cursor(dictionary=True)
    cursor.execute("SELECT * FROM staff_members")
    rows = cursor.fetchall()
    
    staff_list = []
    for row in rows:
        staff = {
            'staff_id': row['staff_id'],
            'organization_email': row['Organization_email'],
            'personal_mail_id': row['Personal_mail_id'],
            'phone_number': row['Phone_number'],
            'date_of_birth': row['Date_of_birth'],
            'street': row['Street'],
            'city': row['City'],
            'pincode': row['Pincode'],
            'date_of_join': row['Date_of_join'],
            'salary': row['Salary'],
            'manager': {'staff_id': row['Manager_id']} if row['Manager_id'] else None,
            'password': row['Password']
        }
        staff_list.append(staff)
        print(staff)
    cursor.close()
    connection.close()
    
    return render(request, 'view_staff_info.html', {'staff_list': staff_list})