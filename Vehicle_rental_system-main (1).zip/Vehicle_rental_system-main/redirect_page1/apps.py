from django.apps import AppConfig


class RedirectPage1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'redirect_page1'
