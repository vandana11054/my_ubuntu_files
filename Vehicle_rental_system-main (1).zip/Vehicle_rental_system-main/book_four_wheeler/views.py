from django.shortcuts import redirect, render
import mysql.connector as sql

def book_fourr_wheeler(request, vehicle_id):
   
       
    conn = sql.connect(host="localhost", user="root", passwd="8675@Tjc2023", database="vehicle_rental_db")
    cursor = conn.cursor(dictionary=True)

    cursor.callproc("search_vehicle", (vehicle_id,))
        
    for result in cursor.stored_results():  
        vehicle = result.fetchone()

  
    conn.close()  


    if request.method == "POST":
        rental_days = request.POST.get("rental_days")
        pickup_date = request.POST.get("pickup_date")

        request.session['rental_days'] = rental_days
        request.session['pickup_date'] = pickup_date 
        request.session['vehicle_id'] = vehicle_id  

        print("Passed vehicle ID:", vehicle_id)
        print("Passed rental days:", rental_days)
        print("Passed pickup date:", pickup_date)
        print("all doneee")
        return redirect("http://127.0.0.1:8000/payment_page/")

    return render(request, 'four_wheeler_book.html', {'vehicle': vehicle})
