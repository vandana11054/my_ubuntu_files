from django.apps import AppConfig


class BookFourWheelerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'book_four_wheeler'
