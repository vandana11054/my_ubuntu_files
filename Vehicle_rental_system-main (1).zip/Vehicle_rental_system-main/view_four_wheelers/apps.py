from django.apps import AppConfig


class ViewFourWheelersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'view_four_wheelers'
