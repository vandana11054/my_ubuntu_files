from django.shortcuts import render
import mysql.connector as sql

def show_four_wheelers(request):
   
    conn = sql.connect(
        host="localhost",
        user="root",
        passwd="8675@Tjc2023",
        database="vehicle_rental_db"
    )
    cursor = conn.cursor(dictionary=True)  
    
    cursor.callproc("show_available_four_wheelers")
        
    # Fetching results
    for result in cursor.stored_results():
        vehicles = result.fetchall()
    
    conn.close()  
    return render(request, 'show_four_wheeler.html', {'vehicles': vehicles})
