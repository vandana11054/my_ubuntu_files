from django.apps import AppConfig


class StaffPageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'staff_page'
