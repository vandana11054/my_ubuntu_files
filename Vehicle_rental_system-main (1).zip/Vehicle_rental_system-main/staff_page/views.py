
from django.shortcuts import render,redirect
import mysql.connector as sql
# Create your views here.
def staff_login(request):
    if request.method == 'POST':
        try:
            obj = sql.connect(host = 'localhost',user = 'root',passwd = '8675@Tjc2023',database='vehicle_rental_db')
            cursor1 = obj.cursor()
            ins = request.POST
            username = ins.get("username","").strip()
            password = ins.get("password","").strip()
            exec = "SELECT * FROM admins WHERE admin_name = %s AND password=%s"
            cursor1.execute(exec,(username,password))
            res = cursor1.fetchall()
            cursor1.close()
            obj.close()

            if not res: 
                return render(request,'no_staff_error.html',{"message":"Invalid login credentials"})
            else:
                if res[0][5] == 'admin':
                      return redirect('http://127.0.0.1:8000/admin_page/')
                if res[0][5] == 'staff':
                      return redirect('http://127.0.0.1:8000/view_booking_data/')
            
        except Exception as err:
            return render(request,'database_error.html',{"message":"Datebase error identified"})
    return render(request,'staff_loginpage.html')