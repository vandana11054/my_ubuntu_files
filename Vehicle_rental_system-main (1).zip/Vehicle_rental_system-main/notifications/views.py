from django.shortcuts import render
import  mysql.connector as sql
from requests import session
# Create your views here.
def show_notifications(request):
    conn = sql.connect(
        host="localhost",
        user="root",
        passwd="8675@Tjc2023",
        database="vehicle_rental_db"
    )
    cursor = conn.cursor(dictionary=True)

    uid = request.session.get("user_id")
    if not uid:
        return render(request, "no_user_error.html", {"error": "User not logged in"})

    cursor.callproc('booked_vhcl_deleted', (uid,))
    
    data = []
    for result in cursor.stored_results():

        data = result.fetchall()

    unique_data = list({tuple(d.items()) for d in data})


    unique_data = [dict(t) for t in unique_data]
   
    cursor.close()
    conn.close()

    return render(request, "notifications.html", {'booking_details': unique_data})
