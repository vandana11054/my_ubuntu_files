from django.shortcuts import render, redirect
import mysql.connector as sql
from datetime import datetime, date
def view_my_bookings(request):
    uid = request.session.get("user_id")
    if not uid:
        return render(request, "no_user_error.html", {"error": "User not logged in"})

    try:
        conn = sql.connect(
            host="localhost",
            user="root",
            passwd="8675@Tjc2023",
            database="vehicle_rental_db"
        )
        cursor = conn.cursor(dictionary=True)

        
        if request.method == "POST":
            booking_id = request.POST.get("booking_id")
            if booking_id:
                cursor.callproc("cancel_booking", (booking_id,))
                conn.commit()

       
        cursor.callproc('vehicles_booked_by_me', (uid,))

        
        booked_vehicles = []
        for result in cursor.stored_results():  
            booked_vehicles = result.fetchall()

        for booking in booked_vehicles:
            pickup_date = booking["pickup_date"]
            end_date = booking["end_date"]

            if isinstance(pickup_date, str):
                pickup_date = datetime.strptime(pickup_date, "%Y-%m-%d")
            if isinstance(end_date, str):
                end_date = datetime.strptime(end_date, "%Y-%m-%d")

            rental_days = (end_date - pickup_date).days
            rental_days = max(1, rental_days)
            booking["total_amount"] = rental_days * booking["rental_price"]

           
            if booking["is_returned"] == "false":
                booking["due_days"] = (date.today() - end_date).days
            else:
                booking["due_days"] = 0

        cursor.close()
        conn.close()
        today_date = date.today()
        return render(request, 'bookings.html', {'my_bookings': booked_vehicles, 'today_date': today_date})

    except sql.Error as e:
        print(e)
        return render(request, "database_error.html", {"error": "Database connection failed. Please try again later."})
