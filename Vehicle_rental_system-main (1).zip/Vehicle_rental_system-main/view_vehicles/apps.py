from django.apps import AppConfig


class ViewVehiclesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'view_vehicles'
