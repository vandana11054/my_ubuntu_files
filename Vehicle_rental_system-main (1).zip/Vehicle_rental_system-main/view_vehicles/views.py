from django.shortcuts import render

# Create your views here.
def view_vehicles(request):
    return render(request,"view_vehicles.html")