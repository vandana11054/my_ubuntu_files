from django.shortcuts import render
import mysql.connector as sql
from django.utils import timezone

def delvhcl(request):
    message = ""  # Initialize message variable

    if request.method == 'POST':
        try:
            # Establish MySQL connection
            dinst = sql.connect(host='localhost', user='root', passwd='8675@Tjc2023', database='vehicle_rental_db')
            dcursor = dinst.cursor()

            # Get vehicle ID from the form
            dval = request.POST
            veh_id = dval.get("veh_id")

            if veh_id:  # Ensure veh_id is not None
                veh_id = int(veh_id)

                # Call stored procedure
                dcursor.callproc('remove_vehicle', (veh_id, '@message'))
                
                # Retrieve output message
                dcursor.execute("SELECT @message")
                t = dcursor.fetchone()  # Fetch a single row

                if t:
                    message = t[0]  # Extract message from tuple
                else:
                    message = "No response from database."
                print(message)
                # Commit changes
                dinst.commit()
            else:
                message = "Please enter a valid Vehicle ID."

        except Exception as e:
            print(f"Error: {e}")  # Log the error for debugging
            message = "Database error occurred. Please try again."

        finally:
            dcursor.close()
            dinst.close()

    return render(request, 'remove_vehicle.html', {'message': message})
