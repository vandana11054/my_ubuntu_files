from django.apps import AppConfig


class RemoveVehicleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'remove_vehicle'
