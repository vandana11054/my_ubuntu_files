from django.shortcuts import render, redirect
import mysql.connector as sql

def loginaction(request):
    if request.method == 'POST':
        try:
           
            m = sql.connect(host='localhost', user='root', passwd='8675@Tjc2023', database='vehicle_rental_db')
            cursor = m.cursor()


            d = request.POST
            unm = d.get("username", "").strip()
            pwd = d.get("password", "").strip()

        
            print("Entered Username:", unm)
            print("Entered Password:", pwd)

           
           
            cursor.callproc("check_user_details", (unm, pwd))
        
        
            for result in cursor.stored_results():
                t = result.fetchall()

       
            print("Query Result:", t)

            cursor.close()
            m.close()

          
            if not t:
                print("Login failed: No matching user found.")
                return render(request, 'invalid_login_cred.html', {"message": "Invalid username or password"})
            else:
                print("Login successful!")
                request.session['username'] = unm
                
                uid = t[0][0]
                request.session["user_id"] = uid
                return redirect("http://127.0.0.1:8000/redirect1/?#")  

        except Exception as e:
            print("Database error:", e)
            return render(request, 'database_error.html', {"message": "Database connection error"})
        
    return render(request, 'login_page.html')
