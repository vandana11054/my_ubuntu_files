from django.shortcuts import render, redirect
import random
import mysql.connector as sql
from datetime import date, timedelta,datetime
import re  

def do_payment(request):
    if request.method == 'POST':

        try:
           
            m = sql.connect(host='localhost', user='root', passwd='8675@Tjc2023', database='vehicle_rental_db')
            cursor = m.cursor()

            
            d = request.POST
            payment_mode = d.get("payment_method", "").strip()
            print(payment_mode, "   payment mode used")

           
            uid = request.session.get("user_id")
            if not uid:
                return render(request,"no_user_error.html")

            
            vid = request.session.get("vehicle_id")
            sdt_str = request.session.get("pickup_date", "").strip()
            rental_days_str = request.session.get("rental_days", "1").strip()

            if not (vid and sdt_str and rental_days_str):
                return render(request, "database_error.html", {"error": "Missing session data"})

            # Convert dates and calculate end date
            try:
                sdt = date.fromisoformat(sdt_str)
                rental_days = int(rental_days_str)
                if rental_days <= 0:
                    return render(request, "database_error.html", {"error": "Rental days must be positive"})
                edt = sdt + timedelta(days=rental_days)
            except ValueError as ve:
                return render(request, "database_error.html", {"error": "Invalid date or rental days format"})

            # Check for booking collisions
            cursor.callproc("collision_check", (vid, sdt, edt))
            
            for result in cursor.stored_results():  # Fetch results
                existing_booking = result.fetchone()

            if existing_booking:
                return render(request, "collision_rebook.html", {"error": "Vehicle is already booked for the selected dates."})

            # Get vehicle rental price
            cursor.callproc("get_rental_price", (vid,))

            for result in cursor.stored_results():
                price_of_vehicle = result.fetchone()
            if not price_of_vehicle:
                return render(request, "database_error.html", {"error": "Vehicle not found"})
            amount = rental_days * price_of_vehicle[0]

           
            booking_status = "Success" if random.random() <= 0.8 else "Failed"


            # Insert into bookings
            cursor.callproc("insert_booking", (uid, vid, date.today(), sdt, edt, booking_status, 'false'))
            m.commit()
            cursor.execute("SELECT LAST_INSERT_ID()")
            booking_id=cursor.fetchone()
            booking_id=booking_id[0]
           
            # Insert into Transactions if payment succeeds
            if booking_status == "Success":
                
                cursor.callproc("insert_transaction", (booking_id, uid, amount, date.today(), payment_mode, 0))
                       
                m.commit()

                
                cursor.execute("SELECT LAST_INSERT_ID()")
                transaction_id = cursor.fetchone()
                if not transaction_id:
                    return render(request, "database_error.html", {"error": "Failed to retrieve transaction ID"})
                transaction_id = transaction_id[0]  

                
                if payment_mode == "GooglePay":
                    gpay_upi_id = d.get("upi_id", "").strip()
                    # Validate UPI ID format (e.g., example@upi)
                    upi_pattern = re.compile(r'^[a-zA-Z0-9.\-_]+@[a-zA-Z0-9]+$')
                    if not gpay_upi_id or not upi_pattern.match(gpay_upi_id):
                        return render(request, "database_error.html", {"error": "Invalid or missing UPI ID for Google Pay"})
                    
                    
                    cursor.callproc("insert_gpay_transaction", (transaction_id, gpay_upi_id))
                    m.commit()  
                elif payment_mode=="UPI":
                    user_upi_id=d.get("upi_id","").strip()
                    upi_pattern=re.compile(r'^[a-zA-Z0-9.\-_]+@[a-zA-Z0-9]+$')
                    if not user_upi_id or not upi_pattern.match(user_upi_id):
                        return render(request, "database_error.html", {"error": "Invalid or missing UPI ID "})
                    cursor.callproc("insert_upi_transaction", (transaction_id, user_upi_id))
                    m.commit()
                elif payment_mode=="CreditCard":
                    card_number=d.get("card_number","").strip()
                    cvv=d.get("cvv","").strip()
                    expiry_date=d.get("expiry_date","").strip()
                    expiry_date = datetime.strptime(expiry_date, "%Y-%m").date()

                    if not card_number or not cvv or not expiry_date:
                        return render(request, "database_error.html", {"error": "Invalid credit card details "})
                    cursor.callproc("insert_credit_card_transaction", (transaction_id, card_number, cvv, expiry_date))
                    m.commit()
                elif payment_mode=="DebitCard":
                    card_number=d.get("card_number","").strip()
                    cvv=d.get("cvv","").strip()
                    expiry_date=d.get("expiry_date","").strip()
                    expiry_date = datetime.strptime(expiry_date, "%Y-%m").date()

                    if not card_number or not cvv or not expiry_date:
                        return render(request, "database_error.html", {"error": "Invalid debit card details "})
                    cursor.callproc("insert_debit_card_transaction", (transaction_id, card_number, cvv, expiry_date))
                    m.commit()
                

            
            # Render appropriate template based on booking status
            if booking_status == "Failed":
                return render(request, "payment_failed.html")
            else:
                return render(request, "booking_success.html")

        except Exception as e:
            print(e)
            return render(request, "database_error.html", {"error": f"Database error: {str(e)}"})
        finally:
            # Close database connection
            cursor.close()
            m.close()

    return render(request, "payment.html")