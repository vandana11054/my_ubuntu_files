from django.shortcuts import render
import mysql.connector as sql
from datetime import datetime

def update_return_status(request):
    message = ""  

    if request.method == 'POST':
        binst = sql.connect(host='localhost', user='root', passwd='8675@Tjc2023', database='vehicle_rental_db')
        bcursor = binst.cursor()
        bval = request.POST
        book_id = bval.get("book_id")

        if book_id:
            book_id = int(book_id)

            try:
                
                bcursor.execute("SELECT pickup_date FROM booking WHERE booking_id = %s and booking_status='success';", (book_id,))
                result = bcursor.fetchone()

                if result:
                    pickup_date = result[0]
                    today_date = datetime.now().date()

                    if pickup_date < today_date:
                        # Update the booking status if picked up
                        bexec = "UPDATE booking SET is_returned = 'true' WHERE booking_id = %s;"
                        bcursor.execute(bexec, (book_id,))
                        binst.commit()
                        message = "Vehicle return status updated successfully!"
                    else:
                        message = "Vehicle not yet picked up. You can return it only after pickup."

                else:
                    message = "No booking found with the given Booking ID."

            except Exception as e:
                message = "An error occurred while processing the request."

            finally:
                bcursor.close()
                binst.close()

    return render(request, 'update_return_status.html', {'message': message})
