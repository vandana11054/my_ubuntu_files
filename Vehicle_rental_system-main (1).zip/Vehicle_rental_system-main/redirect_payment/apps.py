from django.apps import AppConfig


class RedirectPaymentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'redirect_payment'
