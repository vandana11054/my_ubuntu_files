from django.shortcuts import render
from do_payment.views import do_payment
def process_payment(request):
    if request.method == "POST":
        payment_method = request.POST.get("payment_method")

        if payment_method == "GooglePay" or payment_method == "UPI":
            upi_id = request.POST.get("upi_id")
            return do_payment(request)

            

        elif payment_method in ["CreditCard", "DebitCard"]:
            card_number = request.POST.get("card_number")
            expiry_date = request.POST.get("expiry_date")
            cvv = request.POST.get("cvv")
            
            return do_payment(request)


    return render(request, "payment.html") 
