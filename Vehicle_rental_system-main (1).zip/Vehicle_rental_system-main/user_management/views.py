from django.shortcuts import render
import mysql.connector as sql
from django.utils import timezone
# Create your views here.
def userMngmt(request):
     inst = sql.connect(host='localhost',user='root',passwd='8675@Tjc2023',database='vehicle_rental_db')
     ucursor = inst.cursor(dictionary=True)
     ucursor.execute("SELECT * FROM booking WHERE booking_status != 'Failed' ")
     bookings = ucursor.fetchall()
     inst.close()
     curr_date = timezone.now().date()
     return render(request,'user_management.html',{'bookings':bookings,'curr_date':curr_date})