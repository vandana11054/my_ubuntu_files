from django.shortcuts import render
import mysql.connector as sql

def show_two_wheelers(request):
   
    conn = sql.connect(
        host="localhost",
        user="root",
        passwd="8675@Tjc2023",
        database="vehicle_rental_db"
    )
    cursor = conn.cursor(dictionary=True)  
    
    cursor.execute("SELECT * FROM vehicle_details WHERE vehicle_type='2 Wheeler' and availability='available' ")
    vehicles = cursor.fetchall()
    
    conn.close()  
    return render(request, 'show_two_wheeler.html', {'vehicles': vehicles})
