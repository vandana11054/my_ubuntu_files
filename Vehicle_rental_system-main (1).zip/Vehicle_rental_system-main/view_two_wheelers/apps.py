from django.apps import AppConfig


class ViewTwoWheelersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'view_two_wheelers'
