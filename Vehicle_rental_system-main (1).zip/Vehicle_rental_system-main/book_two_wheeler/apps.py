from django.apps import AppConfig


class BookTwoWheelerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'book_two_wheeler'
