"""
URL configuration for vehicle_rental project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from signup.views import signupaction
from login.views import loginaction
from entry_page.views import welcome_view
from staff_page.views import staff_login
from redirect_page1.views import redirect_from_login_page
from two_wheelers.views import two_wheelers_vehicle_list
from four_wheelers.views import four_wheelers_vehicle_list
from book_two_wheeler.views import book_twoo_wheeler
from book_four_wheeler.views import book_fourr_wheeler
from redirect_payment.views import process_payment
from do_payment.views import do_payment
from my_bookings.views import view_my_bookings
from notifications.views import show_notifications
from staff.views import bookingdata
from main_admin.views import manage_admin
from add_vehicle.views import addvhcl
from remove_vehicle.views import delvhcl
from user_management.views import userMngmt
from view_staff_details.views import staff
from view_two_wheelers.views import show_two_wheelers
from view_four_wheelers.views import show_four_wheelers
from view_vehicles.views import view_vehicles
from update_return_status.views import update_return_status
urlpatterns = [
    path('admin/', admin.site.urls),
    path('signup/',signupaction),
    path('login/',loginaction),
    path('',welcome_view,name='home'),
    path('staff_login/',staff_login),
    path('redirect1/',redirect_from_login_page),
    path('two_wheelers/',two_wheelers_vehicle_list),
    path('four_wheelers/',four_wheelers_vehicle_list),
    path('book_two_wheeler/<int:vehicle_id>/', book_twoo_wheeler),
    path('book_four_wheeler/<int:vehicle_id>/',book_fourr_wheeler),
    path('payment_page/',process_payment),
    path("do_payment/", do_payment),
    path("bookings_done/",view_my_bookings),
    path("show_notifications/",show_notifications),
    path("view_booking_data/",bookingdata),
    path("admin_page/",manage_admin),
    path("add_vehicle/",addvhcl),
    path("remove_vehicle/",delvhcl),
    path("user_management/",userMngmt),
    path("staff_info/",staff),
    path("view_two_wheelers/",show_two_wheelers),
    path("view_four_wheelers/",show_four_wheelers),
    path("show_vehicles/",view_vehicles),
    path("update_return_status/",update_return_status),
    
]
