import mysql.connector as sql
from django.shortcuts import render,redirect
from django.utils import timezone
def bookingdata(request):
     inst = sql.connect(host='localhost',user='root',passwd='8675@Tjc2023',database='vehicle_rental_db')
     ucursor = inst.cursor(dictionary=True)
     ucursor.execute("SELECT * FROM booking WHERE booking_status = 'Success' ")
     bookings = ucursor.fetchall()
     inst.close()
     curr_date = timezone.now().date()
     return render(request,'bookingdata.html',{'bookings':bookings,'curr_date':curr_date})