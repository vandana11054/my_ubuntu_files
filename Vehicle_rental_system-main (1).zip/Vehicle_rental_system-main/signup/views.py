from django.shortcuts import render, redirect
import mysql.connector as sql
fn=''
un=''
ph=''
ec=''
em=''
pc=''
st=''
gd=''
lid=''
dob=''
pwd=''
# Create your views here.
def signupaction(request):
    global fn, un, ph, ec, em, pc, st, gd, lid, dob, pwd

    if request.method=='POST':
        m=sql.connect(host='localhost',user='root',passwd='8675@Tjc2023',database='vehicle_rental_db')
        cursor=m.cursor()
        d=request.POST
        for key, value in d.items():
            if key=="name":
                fn=value
            elif key=="username":
                un=value
            elif key=="password":
                pwd=value
            elif key=="phone":
                ph=value
            elif key=="emergency":
                ec=value
            elif key=="email":
                em=value
            elif key=="pincode":
                pc=value
            elif key=="street":
                st=value
            elif key=="gender":
                gd=value
            elif key=="license_id":
                lid=value
            elif key=="dob":
                dob=value
        try:
            c = "INSERT INTO users (name, username, phone, emergency_contact, email, pincode, street, gender, license_id, dob, password) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
            cursor.execute(c, (fn, un, ph, ec, em, pc, st, gd, lid, dob, pwd))
            m.commit()
            request.session['username'] = un
            cursor.execute("SELECT user_id FROM users WHERE username = %s", (un,))
            result = cursor.fetchone()
            uid = result[0]
            request.session["user_id"] = uid
        except:
            return render(request,"existing_credentials_error.html")
        return redirect("http://127.0.0.1:8000/redirect1/?#")


    return render(request,"signup_page.html")
