
#include<iostream>
#include<algorithm>
#include<fstream>
#include<string>
#include<algorithm>
#include<utility>
#include<cmath>
#include"functions.hpp"
#include"Iimpl.hpp"
#include"Rimpl.hpp"
#include"Simpl.hpp"
#include"Uimpl.hpp"
#include"Bimpl.hpp"
#include"Jimpl.hpp"
using namespace std;

string Rfunc7(string a){
	if(a=="sra" || a=="sub")   return "0100000" ;                                                  
	else if(a=="add"||a=="xor"||a=="or"||a=="and"||a=="sll"||a=="srl") 
		return "0000000";                                                   
	return "error";                                                 
}
string Rfunc3(string a){
	if(a=="add" || a=="sub")   return "000" ;                                                  
	else if(a=="srl"|| a=="sra") return "101";                                                   
	else if(a=="sll") return "001";                                                   
	else if(a=="xor") return "100";                                                                                   
	else if(a=="or") return "110";                                                
	else if(a=="and") return "111";                                               
	return "error";
}

string Sfunc3(string a)
{
	if(a=="sb")
		return "000";
	else if(a=="sh")
		return "001";
	else if(a=="sw")
		return "010";
	else if(a=="sd")
		return "011";
	return "error";
}
string Ifunc3(string a)
{
	if (a == "addi")
		return "000";

	else if (a == "xori")
		return "100";

	else if (a == "ori")
		return "110";

	else if (a == "andi")
		return "111";

	else if (a == "slli")
		return "001";

	else if (a == "srli")
		return "101";

	else if (a == "srai")
		return "101";

	else if (a == "jalr")
		return "000";
	else if (a == "lb")
		return "000";
	else if (a == "lh")
		return "001";
	else if (a == "lw")
		return "010";
	else if (a == "ld")
		return "011";
	else if (a == "lbu")
		return "100";
	else if (a == "lhu")
		return "101";
	else if (a == "lwu")
		return "110";
	return "error";
}
string Ifunc6(string a)
{
	if (a == "slli")
		return "000000";

	else if (a == "srli")
		return "000000";

	else if (a == "srai")
		return "010000";
	return "error";
}
string Bfunc3(string func){        //3 bits of func3 returned
	if(func=="beq")       return "000";
	else if(func=="bne")  return "001";
	else if(func=="blt")  return "100";
	else if(func=="bge")  return "101";
	else if(func=="bltu") return "110";
	else if(func=="bgeu") return "111";
	return "error3";    //invalid function 
}
string constant(string imm,string value,string Opcode){
	//function to provide a 20 bit binary value for a decimal number(string value)
	int temp = stoi(value); 
	// convert value to integer 
	if((temp>= -2048 && temp<=2047)||(temp>=-4096 && temp<=4094 && Opcode=="1100011" )){
		//for B format range of immediate is [-4096,4094] 
		//for I,S  formats range of immediate is [-2048,2047]
		if(temp<0){ 
			// if immediate is negative
			bool a= true; 
			// variable that indicates right-most one is met or not for calculating 2's
			// complement in simple method
			temp = 0-temp; //convert imm to positive
			int i=0;
			for(;i<12;i++){ //loop for generating binary equivalent of  +ve decimal number
				imm.push_back(temp%2 + '0'); 
				temp = temp/2;
				if(temp==1){
					imm.push_back(1+'0');
					i++;
					break;
				}
			}
			while(i<11){ //if number of bits in immediate's binary form < 12 
				imm.push_back('0');
				i++;
			}
			for(int u=0;u<11;u++){ 
				//loop for calculating 2's complement of a given  binary number
				if(imm[u]==1+'0'){ //encounter left-most one (still imm. is not reversed)
					a=false;
					for(int k=u+1;k<12;k++){ //flip all other bits that are left
						if(imm[k]==0+'0') imm[k]=1+'0'; 
						else if(imm[k]==1+'0') imm[k]=0+'0';
					}
				}
				if(a==false) break;
			}
		}
		else{  //if immediate value is positive 
			int i=0;
			for(;i<12;i++){ //loop for generating binary equivalent of  +ve decimal number
				imm.push_back(temp%2 + '0');
				temp = temp/2;
				if(temp==1){
					imm.push_back(1+'0');
					i++;
					break;
				}
			}
			while(i<11){ //if number of bits in immediate's binary form < 12
				imm.push_back(0+'0');
				i++;
			}
		}
		reverse(imm.begin(),imm.end());//now reverse string imm to get correct binary value
		return imm;
	}else{
		return "rangeError"; //out_of_range error 
	}
}
string Bformat(string line,string rs1,string rs2,string func,string imm,string in,int i,int count,vector<pair<int,string>> label,vector<pair<string,string>> * regs,string * PC,string *exec,int * stepper){
	//function to generate binary format of given instruction
	bool next = true;
	i++;
	for(;i<line.length();i++){
		if(line[i]!=',' && !(isspace(line[i]))){
			//second argument(rs1) terminates at comma or space
			next = false;
			rs1.push_back(line[i]);
		}
		else if(line[i]==',') break;
	}
	i++;
	next = true;
	for(;i<line.length();i++){
		if(line[i]!=','&& !(isspace(line[i]))){
			// rs2 terminates with comma or space
			next = false;
			rs2.push_back(line[i]);
		}
		else if(line[i]==',' && !(next)) break;
	}
	next =true;
	string target;  // string to  store decimal immediate value
	for(;i<line.length();i++){
		if(line[i]!=','&& !(isspace(line[i]))){
			next = false;
			target.push_back(line[i]);
		}
	}
	for(int m=0;m<label.size();m++){
		if(label[m].second == target){ 
			*stepper = label[m].first;
			imm =constant(imm,to_string(4*(label[m].first-count)),Opcode(func));
			//label[m].first returns line number of given label
			// label[m].first-count returns no. of lines between label and b-instruction with label 
			break;
		}
		if(label[m].second != target && m==label.size()-1){
			//label not found in vector of pairs (label) 	
			cout<<"label at line "<<count<<" not found"<<endl;
			return "1";
		}
	}
	if(imm.empty()){
		//empty label
		cout<<"Empty label found at line "<<count<<endl;
		return "1";
	}
	bgen(func,reg(rs1),reg(rs2),imm,regs,PC,exec,&count,stepper);
	if(!imm.empty() && (imm != "rangeError")){
		// ignore last bit(imm[0]) and sign-extend 
		imm.pop_back();
		reverse(imm.begin(),imm.end());
		if(imm[10] == 0+'0') imm.push_back(0+'0');
		else if(imm[10] == 1+'0') imm.push_back(1+'0');
		reverse(imm.begin(),imm.end());	  
	}
	if(imm != "rangeError") {  
		in.append(imm.substr(0,1));//imm[12]
		in.append(imm.substr(2,6));//imm[10:5]
	}else{
		cout<<"Immediate out of range in line "<<count<<endl;
		return "1";
	}
	if(reg(rs2)!="invalid")  {
		in.append(reg(rs2));
	}else{
		cout<<"Invalid identifier at source register-2 in line "<<count<<endl;
		return "1"; 
	}
	if(reg(rs1)!="invalid"){
		in.append(reg(rs1));
	}else{
		cout<<"Invalid identifier at source register-1 in line "<<count<<endl;
		return "1"; 
	}
	if(Bfunc3(func)!="error3") { //3 bits of func3 appended
		in.append(Bfunc3(func));
	}else{
		cout<<"Suspected wrong function syntax in line "<<count<<endl;
		return "1";
	}
	if(imm != "rangeError"){
		in.append(imm.substr(8,4)); //imm[4:1]
		in.append(imm.substr(1,1)); //imm[11]
	}
	in.append(Opcode(func));
	return in;
}

string Rformat(string line,string rd,string rs1,string rs2,string func,string in,int i,
		vector<pair<string,string>> * regs){
	bool next = true;
	i++;
	for(;i<line.length();i++){
		if(line[i]!=',' && !(isspace(line[i]))){
			next = false;
			rd.push_back(line[i]);
		}
		else if(line[i]==',') break;
	}
	i++;
	next = true;
	for(;i<line.length();i++){
		if(line[i]!=','&& !(isspace(line[i]))){
			next = false;
			rs1.push_back(line[i]);
		}
		else if(line[i]==',' && !(next)) break;
	}
	if(Rfunc7(func)=="error"){
		cout<<"Invalid operation in the instruction"<<endl;
		return "1";
	}else{
		in.append(Rfunc7(func));
	}
	i++;
	next =true;
	for(;i<line.length();i++){
		if(line[i]!=','&& !(isspace(line[i]))){
			next = false;
			rs2.push_back(line[i]);
		}
		else if(line[i]==',' && !(next)) break;
	}
	if(reg(rs2)!="invalid")  in.append(reg(rs2));
	if(reg(rs1)!="invalid")  in.append(reg(rs1));
	if(Rfunc3(func)!="error") in.append(Rfunc3(func));
	if(reg(rd)!="invalid")  in.append(reg(rd));
	rgen(func,reg(rd),reg(rs1),reg(rs2),regs);	
	in.append(Opcode(func));
	return in;
}
string lowerConstant(string imm,string value){
	int temp = stoi(value);
	int i=0;
	for(;i<6;i++){
		imm.push_back(temp%2 + '0');
		temp = temp/2;
		if(temp==1){
			imm.push_back(1+'0');
			i++;
			break;
		}
	}
	while(i<5){
		imm.push_back('0');
		i++;
	}
	reverse(imm.begin(),imm.end());
	return imm;
}
string Sformat(string line,string rs1,string rs2,string func,string imm,string in,int i,int count,vector<pair<string,string>> * regs,string* text,vector<pair<string,string>> * data){
	i++;
	for(;i<line.length();i++){
		if(!isspace(line[i]) && line[i]!=','){
			//second argument terminating characters are comma and blank space
			rs2.push_back(line[i]);
		}
		else if(line[i]==',' ) break;
	}
	string temp;
	i++;
	for(;i<line.length();i++){
		if(((int)line[i] <=57 && (int)line[i] >= 48 && !(isspace(line[i])))||(int)line[i]==45){  // number or minus sign is pushed to temporary string
			temp.push_back(line[i]);
		}
		else if(line[i]=='(') break;  // stop storing at (
	}
	imm =  constant(imm,temp,Opcode(func)); //binary immediate initialised
	bool next = true;
	i++;
	for(;i<line.length(); i++){
		if(line[i]!=')' && line[i]!='(' && !(isspace(line[i]))){
			// argument of form (arg.) stored in rs1
			next = false;
			rs1.push_back(line[i]);
		}
		else if(line[i]==')' && !(next)) break; //stop storing at )
	}
	if(imm != "rangeError") {
		in.append(imm.substr(0,7)); //imm[11:5]
	}else{
		cout<<"Immediate out of range in line "<<count<<endl;
		return "1";
	}
	if(reg(rs2)!="invalid") {
		in.append(reg(rs2));  //append 5 bits of source register
	}else{
		cout<<"Invalid identifier at source register-2 in line "<<count<<endl;
		return "1"; 
	}
	if(reg(rs1)!="invalid"){
		in.append(reg(rs1)); //append 5 bits of source register
	}else{
		cout<<"Invalid identifier at source register-1 in line "<<count<<endl;
		return "1"; 
	}
	if(Sfunc3(func)!="error3") { //3 bits of func3 appended
		in.append(Sfunc3(func));
	}else{
		cout<<"Suspected syntax error at function in line "<<count<<endl;
		return "1";
	}
	if(imm != "rangeError")  in.append(imm.substr(7,5));//imm[4:0]
	in.append(Opcode(func));
	store(func,reg(rs2),reg(rs1),imm,regs,text,data);	
	return in;
}
string IGformat (string line,string rs1,string func,string imm,string rd,string in,int i,int count,vector<pair<string,string>> * regs){ //function for general I-format instruction parsing
	bool next = true;
	i++;
	for(;i<line.length();i++){
		if(line[i]!=',' && !(isspace(line[i]))){
			//second argument(rd) terminates with comma or space
			next = false;
			rd.push_back(line[i]);
		}
		else if(line[i]==',') break;
	}
	i++;
	next = true;
	for(;i<line.length();i++){
		if(line[i]!=','&& !(isspace(line[i]))){
			//third argument(rs1) terminates with comma or space
			next = false;
			rs1.push_back(line[i]);
		}
		else if(line[i]==',' && !(next)) break;
	}
	i++;
	string temp;
	for(;i<line.length();i++){
		if(((int)line[i] <=57 && (int)line[i] >= 48)||(int)line[i]==45){
			//digits or minus symbol appended to string
			temp.push_back(line[i]);
		}
	}
	if(func=="slli" || func=="srli" || func=="srai"){
		imm =  lowerConstant(imm,temp); //6 bit immediate value
		if(Ifunc6(func)!="error6") {
			in.append(Ifunc6(func)); // 6 bits of func6 appended
		}else{
			cout<<"Suspected syntax error at function in line "<<count<<endl;
			return "1";
		}
		if(imm == "rangeError"){
			cout<<"Immediate out of range in line "<<count<<endl;
			return "1"; 
		}	
		in.append(imm); 
	}else{
		imm =  constant(imm,temp,Opcode(func)); //12 bit binary number
		if(imm == "rangeError"){
			cout<<"Immediate value provided is out of range in line "<<count<<endl;
			return "1";
		}
		in.append(imm);
	}
	if(reg(rs1)!="invalid"){
		in.append(reg(rs1));
	}else{
		cout<<"Invalid identifier at source register in line "<<count<<endl;
		return "1"; 
	}
	if(Ifunc3(func)!="error") {
		in.append(Ifunc3(func)); 
	}else{
		cout<<"Suspected syntax error at function in line "<<count<<endl;
		return "1";
	}
	if(reg(rd)!="invalid") {
		in.append(reg(rd));
	}else{
		cout<<"Invalid identifier at destination register in line "<<count<<endl;
		return "1"; 
	}
	igen(func,reg(rd),reg(rs1),imm,regs);	
	in.append(Opcode(func));
	return in;
}
string  ILformat( string line,string rs1,string func,string imm,string rd,string in,int i,int count,string* text,vector<pair<string,string>> * regs,string * PC,string* exec,int* stepper,vector<pair<string,string>> * data,vector<cmem> *cache,string *csize,string *bsize,int* num,bool* cacheOn,int * hits,int * misses,int * aces,string * fout){ 
	//function for  I-format load instruction parsing      
	i++;
	for(;i<line.length();i++){
		if(!isspace(line[i]) && line[i]!=','){
			//second argument(rd) terminating characters are comma and blank space
			rd.push_back(line[i]);
		}
		else if(line[i]==',' ) break;
	}

	string temp;
	i++;
	for(;i<line.length();i++){
		if(((int)line[i] <=57 && (int)line[i] >= 48)||(int)line[i]==45){
			// digit or minus sign is appended
			temp.push_back(line[i]);
		}
		else if(line[i]=='(') break;
	}
	imm =  constant(imm,temp,Opcode(func));
	if(imm == "rangeError") {
		cout<<"Immediate value provided is out of range in line "<<count<<endl;
		return "1";
	}
	in.append(imm);
	bool next = true;
	i++;
	for(;i<line.length(); i++){
		if(line[i]!=')' && line[i]!='(' && !(isspace(line[i]))){
			//input is of the form (rs1)
			next = false;
			rs1.push_back(line[i]);
		}
		else if(line[i]==')' && !(next)) break;
	}
	if(reg(rs1)!="invalid"){
		in.append(reg(rs1));
		iload(func,reg(rd),reg(rs1),imm,regs,text,PC,data,cache,csize,bsize,num,cacheOn,hits,misses,aces,fout);	
	}else{
		cout<<"Invalid identifier at source register-1 in line "<<count<<endl;
		return "1"; 
	}
	if(Ifunc3(func)!="error") { //3 bits of func3 appended
		in.append(Ifunc3(func));
	}else{
		cout<<"Suspected wrong function syntax in line "<<count<<endl;
		return "1";
	}
	if(reg(rd)!="invalid") {
		in.append(reg(rd));
	}else{
		cout<<"Invalid identifier at destination register in line "<<count<<endl;
		return "1"; 
	}
	in.append(Opcode(func));
	return in; //binary instruction returned
}
string upperConstant(string imm,string value,string Opcode){
	//function for calculating 20-bit binary equivalent of a decimal number 
	int temp = stoi(value);
	if((Opcode == "0110111" && temp>=-524288 && temp<=524287)||(Opcode == "1101111" && temp>=-1048576 && temp<=1048574)){ 
		if(temp<0){   //if immediate is negative
			bool a = true;
			temp = 0-temp;
			int i=0;
			for(;i<20;i++){  //calculates binary form of decimal (in reverse order)
				imm.push_back(temp%2 + '0');
				temp = temp/2;
				if(temp==1){
					imm.push_back(1+'0');
					i++;
					break;
				}
			}
			while(i<19){  //if imm. less than 20 bits
				imm.push_back(0+'0');
				i++;
			}
			for(int u=0;u<19;u++){ //loop for calculating 2's complement
				if(imm[u]==1+'0'){
					a=false;
					for(int k=u+1;k<=19;k++){ //after leftmost 1 flip all other bits
						if(imm[k]==0+'0') imm[k]=1+'0';
						else if(imm[k]==1+'0') imm[k]=0+'0';
					}
				}
				if(a==false) break;
			}
			reverse(imm.begin(),imm.end());//reverse imm string to get binary form
		}
		else{ //if immediate is positive
			int i=0;
			for(;i<20;i++){ //calculates binary form of decimal (in reverse order)
				imm.push_back(temp%2 + '0');
				temp = temp/2;
				if(temp==1){
					imm.push_back(1+'0');
					i++;
					break;
				}
			}
			while(i<19){ //if imm. less than 20 bits
				imm.push_back(0+'0');
				i++;
			}
			reverse(imm.begin(),imm.end());
		}
		return imm;
	}else{
		return "rangeError"; //out_of_range error
	}
}

string Uformat(string line,string rd,string func,string imm,string in,int i,int count,vector<pair<string,string>> * regs){
	i++;
	string bintemp;
	string hex_imm;
	for(;i<line.length();i++){
		if(line[i] !=',' && !(isspace(line[i]))){
			// argument terminates with comma or space
			rd.push_back(line[i]);
		}
		else if(line[i] == ',') break;
	}
	string temp;
	for(;i<line.length();i++){
		if(!isspace(line[i]) && line[i]!=',') temp.push_back(line[i]);
	} //temp stores immediate
	if(temp[0] == '0' && temp[1] == 'x'){ //if imm. is in hex format
		if (temp.length()>2)  { //if valid immediate
			temp.erase(0,2);   //erase 0 and x 
			hex_imm  = temp;
			reverse(temp.begin(),temp.end());
			while(temp.length()<5){
				temp.append("0");
			}
			reverse(temp.begin(),temp.end());
			if(temp.length() ==5){
				for(int f=0;f<temp.length();f++){
					in.append(hex_to_bin(temp[f]));   //calculate binary of given hex digit    
				}
			}
		}
		for(int f=0;f<temp.length();f++){
			bintemp.append(hex_to_bin(temp[f]));   //calculate binary of given hex digit
		}
	}
	else{  
		imm = upperConstant(imm,temp,Opcode(func));//20-bit imm. appended
		bintemp.append(imm);
	}
	if(imm != "rangeError" )  {
		in.append(imm.substr(0,20));
	}else{
		cout<<"Immediate out of range in line "<<count<<endl;
		return "1";
	}
	if(reg(rd)!= "invalid") {
		in.append(reg(rd));
	}else{
		cout<<"Invalid identifier at destination register in line "<<count<<endl;
		return "1"; 
	}
	if(Opcode(func)!="invalid")  in.append(Opcode(func)); 
	upper_imm(reg(rd),hex_imm,regs);
	return in;
}
string Jformat(string line,string rd,string func,string imm,string in,int i,int count,
		vector<pair<int,string>> label,vector<pair<string,string>>* regs,string* PC,string* exec,int* stepper){
	//function that parses J-instruction to binary format
	bool next = true;
	i++;
	for (; i < line.length(); i++)
	{
		if (line[i] != ',' && !(isspace(line[i])))
		{ //second argument terminates with comma or space
			next = false;
			rd.push_back(line[i]);
		}
		else if (line[i] == ',')
			break;
	}
	i++;
	next = true;
	string target;
	for (; i < line.length(); i++)
	{ //target stores label name
		if (line[i] != ',' && !(isspace(line[i])))
		{
			next = false;
			target.push_back(line[i]);
		}
	}
	int p=0;
	for (int m = 0; m < label.size(); m++)
	{
		if (label[m].second == target)
		{    //if label name present in vector of pairs label
			p=1;
			*stepper = label[m].first;
			imm = upperConstant(imm,to_string(4*(label[m].first-count)),Opcode(func));
			break;
		}
	}
	if(!p)    imm = upperConstant(imm,target,Opcode(func));
	if(*stepper !=1) *stepper = *stepper -count;
	jgen(func,reg(rd),imm,regs,PC,exec,&count,stepper);
	if (imm != "rangeError")
	{   //ignore last bit and extend sign
		imm.pop_back();
		reverse(imm.begin(),imm.end());	  
		if(imm[18] == 0+'0')      imm.push_back(0+'0');
		else if(imm[18] == 1+'0') imm.push_back(1+'0');
		reverse(imm.begin(),imm.end());	  
	}else{
		cout<<"Immediate value out of range in line "<<count<<endl;
		return "1";
	}
	in.append(imm.substr(0, 1));//imm[20]
	in.append(imm.substr(10, 10));//imm[10:1]
	in.append(imm.substr(9,1));//imm[11]
	in.append(imm.substr(1,8));//imm[19:12]
	if (reg(rd) != "invalid") {
		in.append(reg(rd));
	}else{
		cout<<"Invalid identifier at destination register in line "<<count<<endl;
		return "1"; 
	}
	in.append(Opcode(func));
	return in;
}
int main(int argc,char* argv[])
{
	vector<pair<string,string>> regs;
	vector<pair<string,string>> data;
	vector<cmem> cache;
	bool noloop = false;
	int control =0;
	for(int f=0;f< 262144;f++){ //initialising data section 
		string bcurr;
		int addr = 65536+f;          //caculating address
		for(int l=0;l<20;l++){ //loop for generating binary equivalent of  +ve decimal number
			bcurr.push_back((addr)%2+'0'); 
			addr = addr/2;
			if(addr==1){
				bcurr.push_back(1+'0');
				break;
			}
		}                       
		string curr;
		for(int i=0;i<bcurr.length();i=i+4){      //hexadecimal address calculation
			string bin = bcurr.substr(i,4);
			reverse(bin.begin(),bin.end());
			char c= conv(stoi(bin));
			curr.push_back(c);
		}
		curr.append("x0");
		reverse(curr.begin(),curr.end());
		data.push_back(make_pair(curr,"0x0"));  //initialising data section to default value 0x0
		curr.erase();
		bcurr.erase();
	}
	string PC = "0x00000000";
	bool cacheOn = false; //variable for cache state
	bool load = false;
	string cmd;         //to store given command
	int idx=0;
	int stepper=1;      //to decide which instruction should be executed next
	string text[65536] = {"0x00"};
	static int end=0;
	vector<pair<int,string>> label; //A vector of pairs for storing label name,line
					//number pairs
	ifstream config("config.txt");
	ifstream step("config.txt");
	string csize; //variables for cache size,block size,associativity,replacement policy,write policy
	string bsize;
	string ass;
	string repl;
	string write;
	int num=0;    //variables for number of lines,hits,misses,accesses
	int hits=0;
	int misses = 0;
	int aces=0;
	int step_count=0;
	string fout; //output file 
	string ftemp; //temp variable to find if instruction is load
	string file;  //stores filename
	string fltemp;//loads filename
	while( cmd!="exit"){
		getline(cin,cmd);
		bool fspace = false;
		int f=0;
                  for(;f<cmd.length();f++){
                        if( isspace(cmd[f]) && !fspace) f++;
			else if(!isspace(cmd[f])){
                             fspace= true;
			     ftemp.push_back(cmd[f]);
			}
			else break;
		  }
		  fspace = false;
		  string temp;
		  bool dfspace = false;
		  if(ftemp == "cache_sim"){
                     ftemp.erase();
		     string dumped;
		     for(;f<cmd.length();f++){
                         if( isspace(cmd[f]) && !dfspace) f++;
                         if(!isspace(cmd[f])){
                             dfspace= true;
                             dumped.push_back(cmd[f]);
                        }
                        else break;
		     }
		     if(dumped == "dump"){
			  if(!cacheOn) cout<<"Cache is currently disabled"<<endl;
			  else{
			     dfspace = false;
                             dumped.erase();
			     for(;f<cmd.length();f++){
                                   if( isspace(cmd[f]) && !dfspace) f++;
                                   if(!isspace(cmd[f])){
                                   dfspace= true;
                                   dumped.push_back(cmd[f]);
                                   }
                               else break;
			     }
			     ofstream dump(dumped);
			     for(int i=0;i<num;i++){
                                if(cache[i].valid == 'V') {
                                   dump<<"Set: "<<cache[i].set<<", Tag: "<<cache[i].tag<<", Clean"<<endl;
				}
			     }
			     dumped.erase();
			     cout<<endl;
		     }
		     }
		     if(dumped == "stats"){
			  if(!cacheOn) cout<<"Cache is currently disabled"<<endl;
			  else{
           float rate = ((float)hits)/((float)hits+misses);	
	cout<<"D-cache statistics: Accesses="<<aces<<", Hits="<<hits<<", Misses="<<misses<<", Hit Rate="<<rate<<endl;
		     }
			     dumped.erase();
			     cout<<endl;
		  }
		  }
		  if(ftemp == "load"){
			  control = 1;
		  ftemp.erase();
		  hits=0;
		  misses=0;
		  aces=0;
			for(int i=0;i<32;i++){
				temp.push_back('x');
				temp.append(to_string(i));
				regs.push_back(make_pair(reg(temp),"0x0"));
				if(regs[i].second != "0x0") regs[i].second = "0x0";
				temp.erase();
			}
                  for(;f<cmd.length();f++){
                         if( isspace(cmd[f]) && !fspace) f++;
                         if(!isspace(cmd[f])){
                             fspace= true;
			     fltemp.push_back(cmd[f]);
			}
			else break;
		  }
		  cout<<endl;
 		  }
	        if(!fltemp.empty()){
			file.erase();
			file = fltemp;
		        step.close();
		       	step.open(file);
                        fltemp.erase();
                 	for(int i=0;i<file.length();i++){
                        if(file[i] != '.') fout.push_back(file[i]);
                        else if(file[i] == '.') break;
	                }
			fout.append(".output"); //extension to output file added
	ifstream one(file);          //open input file using file stream
				    //while file has not reached end of file
	int labelMatch =0;            //variable for storing line-numbers containing valid labels
	while(!one.eof()){            //loop  for storing instructions with valid labels
		string test;          // string to store line test
		string tfunc;         // test func string to verify input is label or operation
		getline(one,test);
		if(!test.empty()){
			labelMatch+=1;
			int k=0;
			bool empty = true;   // variable to check empty space after reading an argument 
			for(;k<test.length();k++){
				if(isspace(test[k]) && empty) k++; //if space before argument go to next char
				if(!isspace(test[k])){            
					empty = false;
					tfunc.push_back(test[k]); //push non empty argument 
				}
				else break;
			}  
			if(tfunc.find(':') < 100){ //If string is a label
				tfunc.pop_back();             //remove colon
				label.push_back(make_pair(labelMatch,tfunc));
				//make a pair of label name and line number of label
			}	
		}
		tfunc.erase(); //after each line execution erase func argument and instruction
		test.erase();
	}
	one.close();   //close input file
		}
		  ftemp.erase();
		if(cmd == "cache_sim enable config.txt"){ 
			cacheOn = true;
			string ctemp;
			getline(config,ctemp);
			bool cspace = true;
			for(int i=0;i<ctemp.length();i++){
				if(isspace(ctemp[i]) && cspace) i++;
				if(!isspace(ctemp[i])){
					cspace = false;
					csize.push_back(ctemp[i]);
				}
				else break;
			}
			ctemp.erase();
			getline(config,ctemp);
			cspace = true;
			for(int i=0;i<ctemp.length();i++){
				if(isspace(ctemp[i]) && cspace) i++;
				if(!isspace(ctemp[i])){
					cspace = false;
					bsize.push_back(ctemp[i]);
				}
				else break;
			}
			ctemp.erase();
			getline(config,ctemp);
			cspace = true;
			for(int i=0;i<ctemp.length();i++){
				if(isspace(ctemp[i]) && cspace) i++;
				if(!isspace(ctemp[i])){
					cspace = false;
					ass.push_back(ctemp[i]);
				}
				else break;
			}
			ctemp.erase();
			getline(config,ctemp);
			cspace = true;
			for(int i=0;i<ctemp.length();i++){
				if(isspace(ctemp[i]) && cspace) i++;
				if(!isspace(ctemp[i])){
					cspace = false;
					repl.push_back(ctemp[i]);
				}
				else break;
			}
			ctemp.erase();
			getline(config,ctemp);
			cspace = true;
			for(int i=0;i<ctemp.length();i++){
				if(isspace(ctemp[i]) && cspace) i++;
				if(!isspace(ctemp[i])){
					cspace = false;
					write.push_back(ctemp[i]);
				}
				else break;
			}
			ctemp.erase();
			num = ((stol(csize))/(stol(bsize)));
			string stemp;
			for(int i=0;i<num;i++){
				stemp.push_back('0');
			}
			for(int i=0;i<num;i++){
				struct cmem c1;
				string settemp;
				int setvar = stoi(stemp) + i;
				for(int l=0;l<log2(num);l++){ //loop for generating binary equivalent of  +ve decimal number
					settemp.push_back((setvar)%2+'0'); 
					setvar = setvar/2;
					if(setvar==1){
						settemp.push_back(1+'0');
						break;
					}
				}
				if(settemp.length()<log2(num)){
					while(settemp.length()<log2(num)){
						settemp.push_back('0');
					}
				}
				if((settemp.length())%4 !=0){
					while((settemp.length())%4 !=0){
						settemp.pop_back();
					}
				}
				reverse(settemp.begin(),settemp.end());
				for(int i=0;i<settemp.length();i=i+4){
					string bin = settemp.substr(i,4);
					char c= conv(stoi(bin));
					c1.set.push_back(c);
				}
				reverse(c1.set.begin(),c1.set.end());
				c1.set.append("x0");
				reverse(c1.set.begin(),c1.set.end());
				c1.state = "clean";
				cache.push_back(c1);
			}
			cout<<endl;
		}
		if(cmd == "cache_sim invalidate"){
			if(!cacheOn) cout<<"Cache is disabled"<<endl;
			else{
			for(int i=0;i<num;i++){
				cache[i].valid = 'N';
			}
			}
			cout<<endl;
		}
		if(cmd == "cache_sim disable"){
			cacheOn = false;
			cout<<endl;
		}
		if(cmd == "cache_sim status"){
			if(cacheOn) {
				cout << " Cache enabled"<<endl;
				cout << " Cache Size: "<<csize<<endl;
				cout << " Block Size: "<<bsize<<endl;
				cout << " Associativity: "<< ass <<endl;
				cout << " Replacement Policy: "<< repl <<endl;
				cout << " Write Back Policy: "<< write <<endl;
			}
			else { 
				cout<<"Cache disabled"<< endl;
			}
			cout<<endl;
		}
		if(cmd == "run" ){
			if(control){
			hits=0;
			misses=0;
			aces=0;
			string in;               //string for storing instruction in binary format 
						 //each argument of input stored as individual string                     
			ifstream inp(file);
			string func;
			string rd;
			string rs1; 
			string rs2;
			string imm;
			int count=0;
			static int stop=0;
			while(!inp.eof()){  
				string exec;
				string line;
				if(stepper !=1){
					for(int w=1;w<=stepper;w++){
						getline(inp,line);
					}
				}else{
					getline(inp,line);
				}
				if(stepper>1) count = count+stepper;
				else count = count +1;
				stepper =1;
				if(!line.empty()){
					string check;
					string segment;
					bool space=true;
					for(int k=0;k<line.length();k++){
						if(isspace(line[k]) && space) k++;
						if(!isspace(line[k])){
							space = false;
							segment.push_back(line[k]);
						}
						else if(!space && isspace((line[k]))) break;
					}
					space = true;
					if(segment == ".data"){
						int base = 0;
					while(segment != ".text"){
						//inp.ignore(0,'\n');
						segment.erase();
						getline(inp,line);
						bool dnil = false;
						bool wnil = false;
						bool hnil = false;
						bool bnil = false;
						int k=0;
						string type;
						for(int i=0;i<line.length();i++){
							if(line[i]==' ') continue;
							else type.push_back(line[i]);
						}
						if(type == ".dword"){
							dnil  = true;
							getline(inp,line);
							type.erase();
						}else if(type == ".word"){
							wnil  = true;
							getline(inp,line);
							type.erase();
						}else if(type == ".half"){
							hnil  = true;
							getline(inp,line);
							type.erase();	
						}else if(type == ".byte"){
							bnil  = true;
							getline(inp,line);
							type.erase();
						}
						for( ;k<line.length();k++){
							if(isspace(line[k]) && space) k++;
							if(!isspace(line[k])){
								space = false;
								segment.push_back(line[k]);
							}
							else if(!space && isspace((line[k]))) break;
						}
					if(segment == ".dword" || dnil ){
						if(dnil) k=0;
						string datain[100];
						int p=0;
						int sign[line.length()]={0};
						int sgn =0;
						for(;k<line.length();k++){
							if((line[k]==',') || (isspace(line[k]))){
								k++;
							}
							while(line[k]!=',' && !(isspace(line[k])) && k<line.length()){
								if(line[k] == '-') {
									sign[sgn] = 1;
									k++;
								}
								else{
									datain[p].push_back(line[k]);
									k++;
								}
							}
							sgn++;
							p++;
						}
						for(int i=0;i<p;i++){
							string send;
							if(datain[i][1] !='x'){
								if(datain[i].length()<20){  long long  int temp=stol(datain[i]);
									for(int l=0;l<64;l++){ //loop for generating binary equivalent of  +ve decimal number
										send.push_back((temp)%2+'0'); 
										temp = temp/2;
										if(temp==1){
											send.push_back(1+'0');
											break;
										}
									}                       
									if(!sign[i]){
										if(send.length()<64) {
											while(send.length()<64){
												send.push_back('0');
											}
											reverse(send.begin(),send.end());
										}
									}
									else if(sign[i]){
										//reverse(send.begin(),send.end());
										bool lend=true;
										for(int u=0;u<send.length();u++){
											//loop for calculating 2's complement of a given  binary number
											if(send[u]==1+'0'){ //encounter left-most one (still imm. is not reversed)
												lend = false;
												for(int k=u+1;k<send.length();k++){ //flip all other bits that are left
													if(send[k]==0+'0') send[k]=1+'0';
													else if(send[k]==1+'0') send[k]=0+'0';
												}
											}
											if(lend == false) break;
										}
										//reverse(send.begin(),send.end());
										if(send.length()<64) {
											while(send.length()<64){
												send.push_back('1');
											}
											reverse(send.begin(),send.end());
										}
									}
								}
								else if(datain[i].length()>20){
									cout<<"Input data value at 0x"<<base+10000<<" out of bounds"<<endl;
									continue;
									//error call
								}
								string out;
								for(int i=0;i<send.length();i=i+4){
									string bin = send.substr(i,4);
									char c= conv(stoi(bin));
									out.push_back(c);
								}
								reverse(out.begin(),out.end());
								for(int u=0;u<16;u=u+2){
									data[base].second.erase();
									data[base].second.append("0x");
									string dtemp = out.substr(u,2);
									reverse(dtemp.begin(),dtemp.end()); 
									data[base].second.append(dtemp);
									base+=1;
								}
								out.erase();
							}
							else if(datain[i][0] == '0' && datain[i][1] =='x'){
								reverse(datain[i].begin(),datain[i].end());
								datain[i].pop_back();
								datain[i].pop_back();
								if(datain[i].length()>16){
									cout<<"Input at address 0x"<<(base+ 10000)<<" out of bounds"<<endl;
									continue;
								}
								if(datain[i].length()<16){
									while(datain[i].length()<16){
										datain[i].push_back('0');
									}
								}
								for(int u=0;u<16;u=u+2){
									data[base].second.erase();
									data[base].second.append("0x");
									string dtemp = datain[i].substr(u,2);
									reverse(dtemp.begin(),dtemp.end()); 
									data[base].second.append(dtemp);
									base+=1;
								}
							}
						}
					}
					if(segment == ".word" || wnil) {
						if(wnil) k=0;
						string datain[100];
						int p=0;
						int sign[line.length()]={0};
						int sgn =0;
						for(;k<line.length();k++){
							if((line[k]==',') || (isspace(line[k]))){
								k++;
							}
							while(line[k]!=',' && !(isspace(line[k])) && k<line.length()){
								if(line[k] == '-') {
									sign[sgn] = 1;
									k++;
								}
								else{
									datain[p].push_back(line[k]);
									k++;
								}
							}
							sgn++;
							p++;
						}
						for(int i=0;i<p;i++){
							string send;
							if(datain[i][1] !='x'){
								long long int  temp=stol(datain[i]);
								if(temp<4294967296){
									for(int l=0;l<32;l++){ //loop for generating binary equivalent of  +ve decimal number
										send.push_back((temp)%2+'0'); 
										temp = temp/2;
										if(temp==1){
											send.push_back(1+'0');
											break;
										}
									}                       
									if(!sign[i]){
										if(send.length()<32) {
											while(send.length()<32){
												send.push_back('0');
											}
											reverse(send.begin(),send.end());
										}
									}
									else if(sign[i]){
										//reverse(send.begin(),send.end());
										bool lend=true;
										for(int u=0;u<send.length();u++){
											//loop for calculating 2's complement of a given  binary number
											if(send[u]==1+'0'){ //encounter left-most one (still imm. is not reversed)
												lend = false;
												for(int k=u+1;k<send.length();k++){ //flip all other bits that are left
													if(send[k]==0+'0') send[k]=1+'0';
													else if(send[k]==1+'0') send[k]=0+'0';
												}
											}
											if(lend == false) break;
										}
										//reverse(send.begin(),send.end());
										if(send.length()< 32) {
											while(send.length()< 32){
												send.push_back('1');
												}
												reverse(send.begin(),send.end());
											}
										}
									}
									else{
										cout<<"Input data value at 0x"<<base+10000<<" out of bounds"<<endl;
										continue;
										//error call
									}
									string out;
									for(int i=0;i<send.length();i=i+4){
										string bin = send.substr(i,4);
										char c= conv(stoi(bin));
										out.push_back(c);
									}
									reverse(out.begin(),out.end());
									for(int u=0;u<8;u=u+2){
										data[base].second.erase();
										data[base].second.append("0x");
										string dtemp = out.substr(u,2);
										reverse(dtemp.begin(),dtemp.end()); 
										data[base].second.append(dtemp);
										base+=1;
									}
									out.erase();
								}
								else if(datain[i][0] == '0' && datain[i][1] =='x'){
									reverse(datain[i].begin(),datain[i].end());
									datain[i].pop_back();
									datain[i].pop_back();
									if(datain[i].length()>8){
										cout<<"Input at address 0x"<<(base+ 10000)<<" out of bounds"<<endl;
										continue;
									}
									if(datain[i].length()<=8){
										while(datain[i].length()<8){
											datain[i].push_back('0');
										}
									}
									for(int u=0;u<8;u=u+2){
										data[base].second.erase();
										data[base].second.append("0x");
										string dtemp = datain[i].substr(u,2);
										reverse(dtemp.begin(),dtemp.end()); 
										data[base].second.append(dtemp);
										base+=1;
									}
								}
							}
						}else if(segment == ".half" || hnil){
							if(hnil) k=0;
							string datain[100];
							int p=0;
							int sign[line.length()]={0};
							int sgn =0;
							for(;k<line.length();k++){
								if((line[k]==',') || (isspace(line[k]))){
									k++;
								}
								while(line[k]!=',' && !(isspace(line[k])) && k<line.length()){
									if(line[k] == '-') {
										sign[sgn] = 1;
										k++;
									}
									else{
										datain[p].push_back(line[k]);
										k++;
									}
								}
								sgn++;
								p++;
							}
							for(int i=0;i<p;i++){
								cout<<datain[i]<<endl;
								string send;
								if(datain[i][1] !='x'){
									long long  int temp=stol(datain[i]);
									if(temp<65536){
										for(int l=0;l<16;l++){ //loop for generating binary equivalent of  +ve decimal number
											send.push_back((temp)%2+'0'); 
											temp = temp/2;
											if(temp==1){
												send.push_back(1+'0');
												break;
											}
										}                       
										if(!sign[i]){
											if(send.length()<16) {
												while(send.length()<16){
													send.push_back('0');
												}
												reverse(send.begin(),send.end());
											}
										}
										else if(sign[i]){
											//reverse(send.begin(),send.end());
											bool lend=true;
											for(int u=0;u<send.length();u++){
												//loop for calculating 2's complement of a given  binary number
												if(send[u]==1+'0'){ //encounter left-most one (still imm. is not reversed)
													lend = false;
													for(int k=u+1;k<send.length();k++){ //flip all other bits that are left
														if(send[k]==0+'0') send[k]=1+'0';
														else if(send[k]==1+'0') send[k]=0+'0';
													}
												}
												if(lend == false) break;
											}
											//reverse(send.begin(),send.end());
											if(send.length()< 16) {
												while(send.length()< 16){
													send.push_back('1');
												}
												reverse(send.begin(),send.end());
											}
										}
									}
									else{
										cout<<"Input data value at 0x"<<base+10000<<" out of bounds"<<endl;
										continue;
										//error call
									}
									string out;
									for(int i=0;i<send.length();i=i+4){
										string bin = send.substr(i,4);
										char c= conv(stoi(bin));
										out.push_back(c);
									}
									reverse(out.begin(),out.end());
									for(int u=0;u<4;u=u+2){
										data[base].second.erase();
										data[base].second.append("0x");
										string dtemp = out.substr(u,2);
										reverse(dtemp.begin(),dtemp.end()); 
										data[base].second.append(dtemp);
										base+=1;
									}
									out.erase();
								}
								else if(datain[i][0] == '0' && datain[i][1] =='x'){
									reverse(datain[i].begin(),datain[i].end());
									datain[i].pop_back();
									datain[i].pop_back();
									if(datain[i].length()>4){
										cout<<"Input at address 0x"<<(base+ 10000)<<" out of bounds"<<endl;
										continue;
									}
									if(datain[i].length()<=4){
										while(datain[i].length()<4){
											datain[i].push_back('0');
										}
									}
									for(int u=0;u<4;u=u+2){
										data[base].second.erase();
										data[base].second.append("0x");
										string dtemp = datain[i].substr(u,2);
										reverse(dtemp.begin(),dtemp.end()); 
										data[base].second.append(dtemp);
										base+=1;
									}
								}
							}
						}
						else if(segment == ".byte" || bnil){
							if(bnil) k=0;
							string datain[100];
							int p=0;
							int sign[line.length()]={0};
							int sgn =0;
							for(;k<line.length();k++){
								if((line[k]==',') || (isspace(line[k]))){
									k++;
								}
								while(line[k]!=',' && !(isspace(line[k])) && k<line.length()){
									if(line[k] == '-') {
										sign[sgn] = 1;
										k++;
									}
									else{
										datain[p].push_back(line[k]);
										k++;
									}
								}
								sgn++;
								p++;
							}
							for(int i=0;i<p;i++){
								cout<<datain[i]<<endl;
								string send;
								if(datain[i][1] !='x'){
									long long  int temp=stol(datain[i]);
									if(temp<255){
										for(int l=0;l<8;l++){ //loop for generating binary equivalent of  +ve decimal number
											send.push_back((temp)%2+'0'); 
											temp = temp/2;
											if(temp==1){
												send.push_back(1+'0');
												break;
											}
										}                       
										if(!sign[i]){
											if(send.length()< 8) {
												while(send.length()< 8){
													send.push_back('0');
												}
												reverse(send.begin(),send.end());
											}
										}
										else if(sign[i]){
											//reverse(send.begin(),send.end());
											bool lend=true;
											for(int u=0;u<send.length();u++){
												//loop for calculating 2's complement of a given  binary number
												if(send[u]==1+'0'){ //encounter left-most one (still imm. is not reversed)
													lend = false;
													for(int k=u+1;k<send.length();k++){ //flip all other bits that are left
														if(send[k]==0+'0') send[k]=1+'0';
														else if(send[k]==1+'0') send[k]=0+'0';
													}
												}
												if(lend == false) break;
											}
											//reverse(send.begin(),send.end());
											if(send.length()< 8) {
												while(send.length()< 8){
													send.push_back('1');
												}
												reverse(send.begin(),send.end());
											}
										}
									}
									else{
										cout<<"Input data value at 0x"<<base+10000<<" out of bounds"<<endl;
										continue;
										//error call
									}
									string out;
									for(int i=0;i<send.length();i=i+4){
										string bin = send.substr(i,4);
										char c= conv(stoi(bin));
										out.push_back(c);
									}
									reverse(out.begin(),out.end());
									for(int u=0;u<2;u=u+2){
										data[base].second.erase();
										data[base].second.append("0x");
										string dtemp = out.substr(u,2);
										reverse(dtemp.begin(),dtemp.end()); 
										data[base].second.append(dtemp);
										base+=1;
									}
									out.erase();
								}
								else if(datain[i][0] == '0' && datain[i][1] =='x'){
									reverse(datain[i].begin(),datain[i].end());
									datain[i].pop_back();
									datain[i].pop_back();
									if(datain[i].length()>2){
										cout<<"Input at address 0x"<<(base+ 10000)<<" out of bounds"<<endl;
										continue;
									}
									if(datain[i].length()<=2){
										while(datain[i].length()<2){
											datain[i].push_back('0');
										}
									}
									for(int u=0;u<2;u=u+2){
										data[base].second.erase();
										data[base].second.append("0x");
										string dtemp = datain[i].substr(u,2);
										reverse(dtemp.begin(),dtemp.end()); 
										data[base].second.append(dtemp);
										base+=1;
									}

								}
							}

						}
					}
					getline(inp,line);
				}
				int i=0;
				for(int m=0;m<label.size();m++){
					if(count == label[m].first)  { //if line contains label
						string ignoreLabel;      
						// string to ignore labels by pushing to it instead of pushing to function argument
						bool before = true;    // variable to check space is before or after argument  
						for(;i<line.length();i++){
							if(isspace(line[i]) && before) i++;
							if(!isspace(line[i])){
								before = false;
								ignoreLabel.push_back(line[i]);//ignore that label argument
							}
							else break;
						}
						i++;
					}
				}
				space = true;
				for(;i<line.length();i++){
					if(isspace(line[i]) && space) i++;
					if(!isspace(line[i])){
						space = false;
						func.push_back(line[i]);
					}
					else break;
				}
				check = Opcode(func);
				if(check=="error"){
					string temp = func;
					func.erase();
					space = true;
					for(;i<line.length();i++){
						if(isspace(line[i]) && space) i++;
						if(!isspace(line[i])){
							space = false;
							func.push_back(line[i]);
						}
						else break;
					}
				}
				if(check == "0110011"){
					in = Rformat(line,rd,rs1,rs2,func,in,i,&regs);
				}
				else if(check == "0100011") {
					in = Sformat(line,rs1,rs2,func,imm,in,i,count,&regs,text,&data);
				}                                         
				else if (check=="0000011" || check == "1100111"){
					in= ILformat(line,rs1,func,imm,rd,in,i,count,text,&regs,&PC,&exec,&stepper,&data,&cache,&csize,&bsize,&num,&cacheOn,&hits,&misses,&aces,&fout);
				}
				else if (check == "0010011"){
					in= IGformat(line,rs1,func,imm,rd,in,i,count,&regs);
				}
				else if(check == "1100011"){
					in = Bformat(line,rs1,rs2,func,imm,in,i,count,label,&regs,&PC,&exec,&stepper);
				}
				else if(check == "0110111"){
					in = Uformat(line,rd,func,imm,in,i,count,&regs);
				}else if(check == "1101111"){
					in = Jformat(line,rd,func,imm,in,i,count,label,&regs,&PC,&exec,&stepper);
				}
				if(in== "1")  {
					break;
				}
				string array;
				for(int i=0;i<in.length();i=i+4){
					string bin = in.substr(i,4);
					char c= conv(stoi(bin));
					array.push_back(c);
				}
				int it=0;
				for(int k=0;k<8;k=k+2){
					reverse(array.begin(),array.end());
					string slice;
					slice.append("0x");
					slice.append(array.substr(k+1,1));
					slice.append(array.substr(k,1));
					text[idx+it] = slice;
					reverse(array.begin(),array.end());
					it++;
					}  
					idx=idx+4;
					ofstream obj("output.hex",ios::app);
					if(obj.is_open()){
						obj<<array<<endl;
						obj.close();
					}
					cout<<"Executed "<<line<<" ; ";
					if(exec.empty()){
						cout<<" PC = "<<PC<<endl;
						PC =  PCU(PC,"100");
					}
					else{
						cout<<" PC = "<<PC<<endl;
						PC.erase();
						PC.append(exec);
						exec.erase();
					}
					array.erase();
					func.erase();
					rd.erase();
					rs1.erase();
					rs2.erase();
					in.erase();
					imm.erase();
				}
			}
if(cacheOn) {
           float rate = ((float)hits)/((float)hits+misses);	
	cout<<"D-cache statistics: Accesses="<<aces<<", Hits="<<hits<<", Misses="<<misses<<", Hit Rate="<<rate<<endl;
}
			cout<<endl;
			inp.close();
			}
                    else cout<<"No input file  loaded"<<endl;
		}
		else if(cmd == "regs"){
			string temp;
			string bin;
			for(int i=0;i<32;i++){ 
				temp.push_back('x');
				temp.append(to_string(i));
				cout<<temp;
				if(i<=9) cout<<"   =  ";
				else cout<<"  =  ";
				cout<<regs[i].second<<endl;
				temp.erase();
			}
			cout<<endl;
		}
		if(cmd == "step"){
			if(step.eof()){
				cout<<"nothing to step"<<endl;
			}
			else{
				string in;               //string for storing instruction in binary format 
				string func;
				string rd;
				string rs1; 
				string rs2;
				string imm;
				if(!step.eof()){  
					string exec;
					string line;
					if(stepper !=1){
						for(int w=1;w<=stepper;w++){
							getline(step,line);
						}
					}else{
						getline(step,line);
					}
					if(stepper>1) step_count = step_count+stepper;
					else step_count = step_count +1;
					stepper =1;
					if(!line.empty()){
						string check;
						string segment;
						bool space=true;
						for(int k=0;k<line.length();k++){
							if(isspace(line[k]) && space) k++;
							if(!isspace(line[k])){
								space = false;
								segment.push_back(line[k]);
							}
							else if(!space && isspace((line[k]))) break;
						}
						space = true;
						if(segment == ".data" ){
							int base = 0;
							while(segment != ".text" && !noloop){
								//inp.ignore(0,'\n');
								segment.erase();
								getline(step,line);
								bool dnil = false;
								bool wnil = false;
								bool hnil = false;
								bool bnil = false;
								int k=0;
								string type;
								for(int i=0;i<line.length();i++){
									if(line[i]==' ') continue;
									else type.push_back(line[i]);
								}
								if(type == ".dword"){
									dnil  = true;
									getline(step,line);
									type.erase();
								}else if(type == ".word"){
									wnil  = true;
									getline(step,line);
									type.erase();
								}else if(type == ".half"){
									hnil  = true;
									getline(step,line);
									type.erase();	
								}else if(type == ".byte"){
									bnil  = true;
									getline(step,line);
									type.erase();
								}
								for( ;k<line.length();k++){
									if(isspace(line[k]) && space) k++;
									if(!isspace(line[k])){
										space = false;
										segment.push_back(line[k]);
									}
									else if(!space && isspace((line[k]))) break;
								}
								if(segment == ".dword" || dnil ){
									if(dnil) k=0;
									string datain[100];
									int p=0;
									int sign[line.length()]={0};
									int sgn =0;
									for(;k<line.length();k++){
										if((line[k]==',') || (isspace(line[k]))){
											k++;
										}
										while(line[k]!=',' && !(isspace(line[k])) && k<line.length()){
											if(line[k] == '-') {
												sign[sgn] = 1;
												k++;
											}
											else{
												datain[p].push_back(line[k]);
												k++;
											}
										}
										sgn++;
										p++;
									}
									for(int i=0;i<p;i++){
										string send;
										if(datain[i][1] !='x'){
											if( !(datain[i].empty()) && datain[i].length()<20){  long long  int temp = stol(datain[i]);
												for(int l=0;l<64;l++){ //loop for generating binary equivalent of  +ve decimal number
													send.push_back((temp)%2+'0'); 
													temp = temp/2;
													if(temp==1){
														send.push_back(1+'0');
														break;
													}
												}                       
												if(!sign[i]){
													if(send.length()<64) {
														while(send.length()<64){
															send.push_back('0');
														}
														reverse(send.begin(),send.end());
													}
												}
												else if(sign[i]){
													//reverse(send.begin(),send.end());
													bool lend=true;
													for(int u=0;u<send.length();u++){
														//loop for calculating 2's complement of a given  binary number
														if(send[u]==1+'0'){ //encounter left-most one (still imm. is not reversed)
															lend = false;
															for(int k=u+1;k<send.length();k++){ //flip all other bits that are left
																if(send[k]==0+'0') send[k]=1+'0';
																else if(send[k]==1+'0') send[k]=0+'0';
															}
														}
														if(lend == false) break;
													}
													//reverse(send.begin(),send.end());
													if(send.length()<64) {
														while(send.length()<64){
															send.push_back('1');
														}
														reverse(send.begin(),send.end());
													}
												}
											}
											else if(datain[i].length()>20){
												cout<<"Input data value at 0x"<<base+10000<<" out of bounds"<<endl;
												continue;
												//error call
											}
											string out;
											for(int i=0;i<send.length();i=i+4){
												string bin = send.substr(i,4);
												char c= conv(stoi(bin));
												out.push_back(c);
											}
											reverse(out.begin(),out.end());
											for(int u=0;u<16;u=u+2){
												data[base].second.erase();
												data[base].second.append("0x");
												string dtemp = out.substr(u,2);
												reverse(dtemp.begin(),dtemp.end()); 
												data[base].second.append(dtemp);
												base+=1;
											}
											out.erase();
										}
										else if(datain[i][0] == '0' && datain[i][1] =='x'){
											reverse(datain[i].begin(),datain[i].end());
											datain[i].pop_back();
											datain[i].pop_back();
											if(datain[i].length()>16){
												cout<<"Input at address 0x"<<(base+ 10000)<<" out of bounds"<<endl;
												continue;
											}
											if(datain[i].length()<16){
												while(datain[i].length()<16){
													datain[i].push_back('0');
												}
											}
											for(int u=0;u<16;u=u+2){
												data[base].second.erase();
												data[base].second.append("0x");
												string dtemp = datain[i].substr(u,2);
												reverse(dtemp.begin(),dtemp.end()); 
												data[base].second.append(dtemp);
												base+=1;
											}
										}
									}
								}
								if(segment == ".word" || wnil) {
									if(wnil) k=0;
									string datain[100];
									int p=0;
									int sign[line.length()]={0};
									int sgn =0;
									for(;k<line.length();k++){
										if((line[k]==',') || (isspace(line[k]))){
											k++;
										}
										while(line[k]!=',' && !(isspace(line[k])) && k<line.length()){
											if(line[k] == '-') {
												sign[sgn] = 1;
												k++;
											}
											else{
												datain[p].push_back(line[k]);
												k++;
											}
										}
										sgn++;
										p++;
									}
									for(int i=0;i<p;i++){
										cout<<datain[i]<<endl;
										string send;
										if(datain[i][1] !='x'){
											long long int  temp=stol(datain[i]);
											if(temp<4294967296){
												for(int l=0;l<32;l++){ //loop for generating binary equivalent of  +ve decimal number
													send.push_back((temp)%2+'0'); 
													temp = temp/2;
													if(temp==1){
														send.push_back(1+'0');
														break;
													}
												}                       
												if(!sign[i]){
													if(send.length()<32) {
														while(send.length()<32){
															send.push_back('0');
														}
														reverse(send.begin(),send.end());
													}
												}
												else if(sign[i]){
													//reverse(send.begin(),send.end());
													bool lend=true;
													for(int u=0;u<send.length();u++){
														//loop for calculating 2's complement of a given  binary number
														if(send[u]==1+'0'){ //encounter left-most one (still imm. is not reversed)
															lend = false;
															for(int k=u+1;k<send.length();k++){ //flip all other bits that are left
																if(send[k]==0+'0') send[k]=1+'0';
																else if(send[k]==1+'0') send[k]=0+'0';
															}
														}
														if(lend == false) break;
													}
													//reverse(send.begin(),send.end());
													if(send.length()< 32) {
														while(send.length()< 32){
															send.push_back('1');
														}
														reverse(send.begin(),send.end());
													}
												}
											}
											else{
												cout<<"Input data value at 0x"<<base+10000<<" out of bounds"<<endl;
												continue;
												//error call
											}
											string out;
											for(int i=0;i<send.length();i=i+4){
												string bin = send.substr(i,4);
												char c= conv(stoi(bin));
												out.push_back(c);
											}
											reverse(out.begin(),out.end());
											for(int u=0;u<8;u=u+2){
												data[base].second.erase();
												data[base].second.append("0x");
												string dtemp = out.substr(u,2);
												reverse(dtemp.begin(),dtemp.end()); 
												data[base].second.append(dtemp);
												base+=1;
											}
											out.erase();
										}
										else if(datain[i][0] == '0' && datain[i][1] =='x'){
											reverse(datain[i].begin(),datain[i].end());
											datain[i].pop_back();
											datain[i].pop_back();
											if(datain[i].length()>8){
												cout<<"Input at address 0x"<<(base+ 10000)<<" out of bounds"<<endl;
												continue;
											}
											if(datain[i].length()<=8){
												while(datain[i].length()<8){
													datain[i].push_back('0');
												}
											}
											for(int u=0;u<8;u=u+2){
												data[base].second.erase();
												data[base].second.append("0x");
												string dtemp = datain[i].substr(u,2);
												reverse(dtemp.begin(),dtemp.end()); 
												data[base].second.append(dtemp);
												base+=1;
											}
										}
									}
								}else if(segment == ".half" || hnil){
									if(hnil) k=0;
									string datain[100];
									int p=0;
									int sign[line.length()]={0};
									int sgn =0;
									for(;k<line.length();k++){
										if((line[k]==',') || (isspace(line[k]))){
											k++;
										}
										while(line[k]!=',' && !(isspace(line[k])) && k<line.length()){
											if(line[k] == '-') {
												sign[sgn] = 1;
												k++;
											}
											else{
												datain[p].push_back(line[k]);
												k++;
											}
										}
										sgn++;
										p++;
									}
									for(int i=0;i<p;i++){
										cout<<datain[i]<<endl;
										string send;
										if(datain[i][1] !='x'){
											long long  int temp=stol(datain[i]);
											if(temp<65536){
												for(int l=0;l<16;l++){ //loop for generating binary equivalent of  +ve decimal number
													send.push_back((temp)%2+'0'); 
													temp = temp/2;
													if(temp==1){
														send.push_back(1+'0');
														break;
													}
												}                       
												if(!sign[i]){
													if(send.length()<16) {
														while(send.length()<16){
															send.push_back('0');
														}
														reverse(send.begin(),send.end());
													}
												}
												else if(sign[i]){
													//reverse(send.begin(),send.end());
													bool lend=true;
													for(int u=0;u<send.length();u++){
														//loop for calculating 2's complement of a given  binary number
														if(send[u]==1+'0'){ //encounter left-most one (still imm. is not reversed)
															lend = false;
															for(int k=u+1;k<send.length();k++){ //flip all other bits that are left
																if(send[k]==0+'0') send[k]=1+'0';
																else if(send[k]==1+'0') send[k]=0+'0';
															}
														}
														if(lend == false) break;
													}
													//reverse(send.begin(),send.end());
													if(send.length()< 16) {
														while(send.length()< 16){
															send.push_back('1');
														}
														reverse(send.begin(),send.end());
													}
												}
											}
											else{
												cout<<"Input data value at 0x"<<base+10000<<" out of bounds"<<endl;
												continue;
												//error call
											}
											string out;
											for(int i=0;i<send.length();i=i+4){
												string bin = send.substr(i,4);
												char c= conv(stoi(bin));
												out.push_back(c);
											}
											reverse(out.begin(),out.end());
											for(int u=0;u<4;u=u+2){
												data[base].second.erase();
												data[base].second.append("0x");
												string dtemp = out.substr(u,2);
												reverse(dtemp.begin(),dtemp.end()); 
												data[base].second.append(dtemp);
												base+=1;
											}
											out.erase();
										}
										else if(datain[i][0] == '0' && datain[i][1] =='x'){
											reverse(datain[i].begin(),datain[i].end());
											datain[i].pop_back();
											datain[i].pop_back();
											if(datain[i].length()>4){
												cout<<"Input at address 0x"<<(base+ 10000)<<" out of bounds"<<endl;
												continue;
											}
											if(datain[i].length()<=4){
												while(datain[i].length()<4){
													datain[i].push_back('0');
												}
											}
											for(int u=0;u<4;u=u+2){
												data[base].second.erase();
												data[base].second.append("0x");
												string dtemp = datain[i].substr(u,2);
												reverse(dtemp.begin(),dtemp.end()); 
												data[base].second.append(dtemp);
												base+=1;
											}

										}
									}
								}
								else if(segment == ".byte" || bnil){
									if(bnil) k=0;
									string datain[100];
									int p=0;
									int sign[line.length()]={0};
									int sgn =0;
									for(;k<line.length();k++){
										if((line[k]==',') || (isspace(line[k]))){
											k++;
										}
										while(line[k]!=',' && !(isspace(line[k])) && k<line.length()){
											if(line[k] == '-') {
												sign[sgn] = 1;
												k++;
											}
											else{
												datain[p].push_back(line[k]);
												k++;
											}
										}
										sgn++;
										p++;
									}
									for(int i=0;i<p;i++){
										cout<<datain[i]<<endl;
										string send;
										if(datain[i][1] !='x'){
											long long  int temp=stol(datain[i]);
											if(temp<255){
												for(int l=0;l<8;l++){ //loop for generating binary equivalent of  +ve decimal number
													send.push_back((temp)%2+'0'); 
													temp = temp/2;
													if(temp==1){
														send.push_back(1+'0');
														break;
													}
												}                       
												if(!sign[i]){
													if(send.length()< 8) {
														while(send.length()< 8){
															send.push_back('0');
														}
														reverse(send.begin(),send.end());
													}
												}
												else if(sign[i]){
													//reverse(send.begin(),send.end());
													bool lend=true;
													for(int u=0;u<send.length();u++){
														//loop for calculating 2's complement of a given  binary number
														if(send[u]==1+'0'){ //encounter left-most one (still imm. is not reversed)
															lend = false;
															for(int k=u+1;k<send.length();k++){ //flip all other bits that are left
																if(send[k]==0+'0') send[k]=1+'0';
																else if(send[k]==1+'0') send[k]=0+'0';
															}
														}
														if(lend == false) break;
													}
													//reverse(send.begin(),send.end());
													if(send.length()< 8) {
														while(send.length()< 8){
															send.push_back('1');
														}
														reverse(send.begin(),send.end());
													}
												}
											}
											else{
												cout<<"Input data value at 0x"<<base+10000<<" out of bounds"<<endl;
												continue;
												//error call
											}
											string out;
											for(int i=0;i<send.length();i=i+4){
												string bin = send.substr(i,4);
												char c= conv(stoi(bin));
												out.push_back(c);
											}
											reverse(out.begin(),out.end());
											for(int u=0;u<2;u=u+2){
												data[base].second.erase();
												data[base].second.append("0x");
												string dtemp = out.substr(u,2);
												reverse(dtemp.begin(),dtemp.end()); 
												data[base].second.append(dtemp);
												base+=1;
											}
											out.erase();
										}
										else if(datain[i][0] == '0' && datain[i][1] =='x'){
											reverse(datain[i].begin(),datain[i].end());
											datain[i].pop_back();
											datain[i].pop_back();
											if(datain[i].length()>2){
												cout<<"Input at address 0x"<<(base+ 10000)<<" out of bounds"<<endl;
												continue;
											}
											if(datain[i].length()<=2){
												while(datain[i].length()<2){
													datain[i].push_back('0');
												}
											}
											for(int u=0;u<2;u=u+2){
												data[base].second.erase();
												data[base].second.append("0x");
												string dtemp = datain[i].substr(u,2);
												reverse(dtemp.begin(),dtemp.end()); 
												data[base].second.append(dtemp);
												base+=1;
											}

										}
									}

								}
							}
							if(segment == ".text") noloop = true;
							getline(step,line);
						}
						int i=0;
						space=true;
						for(int m=0;m<label.size();m++){
							if(step_count == label[m].first)  { //if line contains label
								string ignoreLabel;      
								// string to ignore labels by pushing to it instead of pushing to function argument
								bool before = true;    // variable to check space is before or after argument  
								for(;i<line.length();i++){
									if(isspace(line[i]) && before) i++;
									if(!isspace(line[i])){
										before = false;
										ignoreLabel.push_back(line[i]);//ignore that label argument
									}
									else break;
								}
								i++;
							}
						}
						space = true;
						for(;i<line.length();i++){
							if(isspace(line[i]) && space) i++;
							if(!isspace(line[i])){
								space = false;
								func.push_back(line[i]);
							}
							else break;
						}
						check = Opcode(func);
						if(check=="error"){
							string temp = func;
							func.erase();
							space = true;
							for(;i<line.length();i++){
								if(isspace(line[i]) && space) i++;
								if(!isspace(line[i])){
									space = false;
									func.push_back(line[i]);
								}
								else break;
							}
						}
						if(check == "0110011"){
							in = Rformat(line,rd,rs1,rs2,func,in,i,&regs);
						}
						else if(check == "0100011") {
							in = Sformat(line,rs1,rs2,func,imm,in,i,step_count,&regs,text,&data);
						}                                         
						else if (check=="0000011" || check == "1100111"){
							in= ILformat(line,rs1,func,imm,rd,in,i,step_count,text,&regs,&PC,&exec,&stepper,&data,&cache,&csize,&bsize,&num,&cacheOn,&hits,&misses,&aces,&fout);
						}
						else if (check == "0010011"){
							in= IGformat(line,rs1,func,imm,rd,in,i,step_count,&regs);
						}
						else if(check == "1100011"){
							in = Bformat(line,rs1,rs2,func,imm,in,i,step_count,label,&regs,&PC,&exec,&stepper);
						}
						else if(check == "0110111"){
							in = Uformat(line,rd,func,imm,in,i,step_count,&regs);
						}else if(check == "1101111"){
							in = Jformat(line,rd,func,imm,in,i,step_count,label,&regs,&PC,&exec,&stepper);
						}
						if(in== "1"){
							cout<<"Not stepped";
						}
						//if( stop == 1) { //Any error reported as "1"
						//		cout<<"Execution terminated"<<endl;
						//		return 1;
						//	}
						string array;
						for(int i=0;i<in.length();i=i+4){
							string bin = in.substr(i,4);
							char c= conv(stoi(bin));
							array.push_back(c);
						}
						int it=0;
						for(int k=0;k<8;k=k+2){
							reverse(array.begin(),array.end());
							string slice;
							slice.append("0x");
							slice.append(array.substr(k+1,1));
							slice.append(array.substr(k,1));
							text[idx+it] = slice;
							reverse(array.begin(),array.end());
							it++;
						}  
						idx=idx+4;
						ofstream obj("output.hex",ios::app);
						if(obj.is_open()){
							obj<<array<<endl;
							obj.close();
						}
						cout<<"Executed "<<line<<" ; ";
						if(exec.empty()){
							cout<<"PC="<<PC<<endl;
							PC =  PCU(PC,"100");
						}
						else{
							cout<<"PC="<<PC<<endl;
							PC.erase();
							PC.append(exec);
							exec.erase();
						}
						array.erase();
						func.erase();
						rd.erase();
						rs1.erase();
						rs2.erase();
						in.erase();
						imm.erase();
					}
				}
				cout<<endl;
			}
		}
}
	                        step.close();
	if(cmd == "exit"){
		cout<<"Exited the simulator"<<endl;
	}
	return 0;
	}
