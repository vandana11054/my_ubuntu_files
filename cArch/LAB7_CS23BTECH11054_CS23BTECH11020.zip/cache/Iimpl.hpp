

#include<iostream>
#include<fstream>
#include<string>
#include "binfunc.hpp"
using namespace std;

struct cmem {
    string set;
    string tag;
    char valid;
    string state;
    vector<string> mem;
};

void igen(string func,string rd,string rs1,string imm,vector<pair<string,string>> * regs){
	int a=0;
	string temp;
	string adder;
	for(int i=4;i>=0;i--){
		int b=0;
		b+=(rs1[i]-'0');
		for(int k=1;k<5-i;k++){
			b*=2;
		}
		a=a+b;
	}
	temp = regs->at(a).second;
	reverse(temp.begin(),temp.end());
	temp.pop_back();
	temp.pop_back();
	reverse(temp.begin(),temp.end());
	a=0;
	for(int i=4;i>=0;i--){
		int b=0;
		b+=(rd[i]-'0');
		for(int k=1;k<5-i;k++){
			b*=2;
		}
		a = a+b;
	}
	regs->at(a).second.erase();
	string src2;
	for(int k=0;k<temp.length();k++){
		src2.append(hex_to_bin(temp[k]));
	}
	string in;
	if(func == "addi")  in = binadd(imm,src2);
	if(func == "andi")  in = binand(imm,src2);
	if(func == "xori")  in = binxor(imm,src2);
	if(func == "ori")   in = binor(imm,src2);
	if(func == "slli")  in = binsll(src2,imm,func);
	if(func == "srli")  in = binsrl(src2,imm,func);
	if(func == "srai")  in = binsra(src2,imm,func);
	if(in.length()>64){
		reverse(in.begin(),in.end());
		while(in.length()>64) in.pop_back();
		reverse(in.begin(),in.end());  
	}
	for(int i=0;i<in.length();i=i+4){
		string bin = in.substr(i,4);
		char c= conv(stoi(bin));
		adder.push_back(c);
	}

	if(adder.length()<18){
		reverse (adder.begin(),adder.end());
		while(adder.length()<16){
			if(0<=adder[adder.length()-1]-'0' && adder[adder.length()-1]-'0'<8)
				adder.push_back('0');
			else adder.push_back('f');
		}
		adder.push_back('x');
		adder.push_back('0');
		reverse (adder.begin(),adder.end());
	}
	regs->at(a).second = adder;
}

void iload(string func,string rd,string rs1,string imm,vector<pair<string,string>> * regs,string* text,string* PC,vector<pair<string,string>> * data,vector<cmem> *cache,string *csize,string *bsize,int *num,bool *cacheOn,int * hits,int* misses,int* aces,string* 
		fout){
	ofstream fileout(*fout,ios::app);
	int a=0;
	string temp;
	string adder;
	for(int i=4;i>=0;i--){
		int b=0;
		b+=(rs1[i]-'0');
		for(int k=1;k<5-i;k++){
			b*=2;
		}
		a=a+b;
	}
	temp = regs->at(a).second;
	reverse(temp.begin(),temp.end());
	temp.pop_back();
	temp.pop_back();
	reverse(temp.begin(),temp.end());
	a=0;
	for(int i=4;i>=0;i--){
		int b=0;
		b+=(rd[i]-'0');
		for(int k=1;k<5-i;k++){
			b*=2;
		}
		a=a+b;
	}
	regs->at(a).second.erase();
	regs->at(a).second.append("0x");
	string src;
	for(int k=0;k<temp.length();k++){
		src.append(hex_to_bin(temp[k]));
	}
	if(imm.length()<src.length()){
		reverse(imm.begin(),imm.end());
		while(imm.length()<src.length()){
			imm.push_back(imm[imm.length()-1]);
		}
		reverse(imm.begin(),imm.end());
	}
	string in;
	in = binadd(src,imm);
	int din =0;
           for(int i=in.length()-1;i>=0;i--){
               int b=0;
                b+=(in[i]-'0');
               for(int k=1;k< in.length()-i;k++){
                  b*=2;
                   }
                  din = din +b;
                 }
	string input;
	for(int i=0;i<in.length();i=i+4){
		string bin = in.substr(i,4);
		char c= conv(stoi(bin));
		input.push_back(c);
	}
	long long int dec = stol(input);
	reverse(input.begin(),input.end());
	input.append("x0");
	reverse(input.begin(),input.end());
		                bool found =0; //hit or miss variable
				int index=0;
				int setbyte =0;
                if(*cacheOn){	
			(*aces)++;
	         int off = log2(stoi(*bsize)); 
	         int idx = log2(*num);
		 string tag;
		 string set;
		 string ctemp;
		 for(int i=0;i<20-off-idx;i++){
                   ctemp.push_back(in[i]);
		 } 
		 if((ctemp.length()%4) != 0) {
                       reverse(ctemp.begin(),ctemp.end());
		       while((ctemp.length()%4) != 0){
                            ctemp.pop_back();
		       if((ctemp.length()%4) == 0) break;
		       }
                       reverse(ctemp.begin(),ctemp.end());
		 }
				for(int i=0;i<ctemp.length();i=i+4){
					string bin = ctemp.substr(i,4);
					char c= conv(stoi(bin));
					tag.push_back(c);
				}
                       reverse(tag.begin(),tag.end());
				tag.append("x0");
                       reverse(tag.begin(),tag.end());
		       ctemp.erase();
		 for(int i=20-off-idx;i<20-off;i++){
                   ctemp.push_back(in[i]);
		 } 
		 if((ctemp.length()%4) != 0) {
                       reverse(ctemp.begin(),ctemp.end());
		       while((ctemp.length()%4) != 0){
                            ctemp.pop_back();
		       if((ctemp.length()%4) == 0) break;
		       }
                       reverse(ctemp.begin(),ctemp.end());
		 }
				for(int i=0;i<ctemp.length();i=i+4){
					string bin = ctemp.substr(i,4);
					char c= conv(stoi(bin));
					set.push_back(c);
				}
                       reverse(set.begin(),set.end());
				set.append("x0");
                       reverse(set.begin(),set.end());
		       ctemp.erase();
		 for(int i=20-off;i<20;i++){
                   ctemp.push_back(in[i]);
		 } 
	    ctemp.pop_back();
	    ctemp.pop_back();
	    ctemp.pop_back();
           for(int i=ctemp.length()-1;i>=0;i--){
               int b=0;
                b+=(ctemp[i]-'0');
               for(int k=1;k< ctemp.length()-i;k++){
                  b*=2;
                   }
                  setbyte = setbyte +b;
                 }
                 for (int i=0;i< *num;i++){
                          if(cache->at(i).tag == tag && cache->at(i).set == set){
				  found=1;
				  (*hits)++;
                                  index = i;
			  }
                 }
             if(!found){
		      (*misses)++;
                      for(int i=0;i<*num;i++){
                               if(cache->at(i).set == set) {
				       cache->at(i).valid = 'V';
				       cache->at(i).tag.erase();
				       cache->at(i).tag.append(tag);
				       index=i;
			       break;
			       }
		      }
		      for(int m=0;m<50000;m++){
		      if(data->at(m).first == input){
		              int tempin = din % (stoi(*bsize));
			      for(int k=1;k<=(stoi(*bsize));k++){
		   cache->at(index).mem.push_back(data->at(m-tempin+k-1).second);
			      }
			      break;
		      }
		      }
	     }
if(found) fileout<<"R: Address: "<<input<<", Set: "<<cache->at(index).set<<", Hit,"<<" Tag: "<<cache->at(index).tag<<", Clean"<<endl;
if(!found) fileout<<"R: Address: "<<input<<", Set: "<<cache->at(index).set<<", Miss,"<<" Tag: "<<tag<<", Clean"<<endl;
	}
	if(func == "ld"){
					regs->at(a).second.erase();
					regs->at(a).second.append("0x");
	        if(found){
				for(int z=(8*setbyte+7);z>=(8*setbyte);z--){
					string val = cache->at(index).mem[z];
					if(val.empty()){ 
						regs->at(a).second.append("0");
						break;
				        }
					reverse(val.begin(),val.end());
					val.pop_back();
					val.pop_back();
					if(val.length() < 2) {
						while(val.length()<2){
						val.push_back('0');
					}
					}
					reverse(val.begin(),val.end());
					regs->at(a).second.append(val);
				} 
		}
	        if(!(*cacheOn) || !found){
		for(int m=0;m<50000;m++){
			if(data->at(m).first == input){
				for(int z=7;z>=0;z--){
					string val = data->at(m+z).second;
					if(val.empty()) { 
						regs->at(a).second.append("0");
						break;
					}
					reverse(val.begin(),val.end());
					val.pop_back();
					val.pop_back();
					if(val.length() < 2) {
						while(val.length()<2){
						val.push_back('0');
					}
					}
					reverse(val.begin(),val.end());
					regs->at(a).second.append(val);
				}
				break;
			}
		}
		}
	}
	if(func == "lw" || func == "lwu" ){
		regs->at(a).second.erase();
		regs->at(a).second.append("0x");
	        if(found){
				for(int z= (8*setbyte+3);z>=(8*setbyte);z--){
					string val = cache->at(index).mem[z];
					if(val.empty()) { 
						regs->at(a).second.append("0");
						break;
					}
					reverse(val.begin(),val.end());
					val.pop_back();
					val.pop_back();
					if(val.length() < 2) {
						while(val.length()<2){
						val.push_back('0');
					}
					}
					reverse(val.begin(),val.end());
					regs->at(a).second.append(val);
				} 
		}
		if(!(*cacheOn) || !found){
		string word;
		for(int m=0;m<50000;m++){
			if(data->at(m).first == input){
				for(int z=3;z>=0;z--){
					if(dec+z < 0){
						regs->at(a).second.append("0");
						break;
					}
					string temp = data->at(m+z).second;
					if(temp.empty()) { 
						regs->at(a).second.append("0");
						break;
					} 
					reverse(temp.begin(),temp.end());
					temp.pop_back();
					temp.pop_back();
					reverse(temp.begin(),temp.end());
					word.append(temp);
				}
				break;
			}
		}
		reverse(word.begin(),word.end());
		if(word.length()<16){
			if(func == "lw"){
				if(0<=word[word.length()-1]-'0' && word[word.length()-1]-'0'<8){
					while(word.length()<16)  word.push_back('0');
				}else{
					while(word.length()<16)  word.push_back('f');
				}
			}else if(func == "lwu"){
				while(word.length()<16)  word.push_back('0');
			}
		}
		reverse(word.begin(),word.end());
		regs->at(a).second = "0x";
		regs->at(a).second.append(word);
		word.erase();
	}
	}
	if(func == "lh"|| func == "lhu" ){
	        if(found){
				for(int z= (8*setbyte+1);z>=(8*setbyte);z--){
					string val = cache->at(index).mem[z];
					if(val.empty()) { 
						regs->at(a).second.append("0");
						break;
					}
					reverse(val.begin(),val.end());
					val.pop_back();
					val.pop_back();
					if(val.length() < 2) {
						while(val.length()<2){
						val.push_back('0');
					}
					}
					reverse(val.begin(),val.end());
					regs->at(a).second.append(val);
				} 
		}
		if(!(*cacheOn) || !found){
		regs->at(a).second.erase();
		regs->at(a).second.append("0x");
		string half;
		for(int m=0;m<50000;m++){
			if(data->at(m).first == input){
				for(int z=1;z>=0;z--){
					if(dec+z < 0){
						regs->at(a).second.append("0");
						break;
					}
					string temp = data->at(m+z).second;
					if(temp.empty()) { 
						regs->at(a).second.append("0");
						break;
					} 
					reverse(temp.begin(),temp.end());
					temp.pop_back();
					temp.pop_back();
					reverse(temp.begin(),temp.end());
					half.append(temp);
				}
				break;
			}
		}
		reverse(half.begin(),half.end());
		if(half.length()<16){
			if(func=="lh"){
				if(0<=half[half.length()-1]-'0' && half[half.length()-1]-'0'<8){
					while(half.length()<16)  half.push_back('0');
				}else{
					while(half.length()<16)  half.push_back('f');
				}
			}else if(func == "lhu"){
				while(half.length()<16)  half.push_back('0');
			}
		}
		reverse(half.begin(),half.end());
		regs->at(a).second = "0x";
		regs->at(a).second.append(half);
		half.erase();
	}
	}
	if(func == "lb" || func == "lbu"){
	        if(found){
				for(int z= (8*setbyte);z>=(8*setbyte);z--){
					string val = cache->at(index).mem[z];
					if(val.empty()) { 
						regs->at(a).second.append("0");
						break;
					}
					reverse(val.begin(),val.end());
					val.pop_back();
					val.pop_back();
					if(val.length() < 2) {
						while(val.length()<2){
						val.push_back('0');
					}
					}
					reverse(val.begin(),val.end());
					regs->at(a).second.append(val);
				} 
                               }
		if(!(*cacheOn) || !found){
		regs->at(a).second.erase();
		regs->at(a).second.append("0x");
		string byt;
		for(int m=0;m<50000;m++){
			if(data->at(m).first == input){
				for(;;){
					if(dec < 0){
						regs->at(a).second.append("0");
						break;
					}
					string temp = data->at(m).second;
					if(temp.empty()) { 
						regs->at(a).second.append("0");
						break;
					} 
					reverse(temp.begin(),temp.end());
					temp.pop_back();
					temp.pop_back();
					reverse(temp.begin(),temp.end());
					byt.append(temp);
					break;
				}
				break;
			}
		}
		reverse(byt.begin(),byt.end());
		if(byt.length()<16){
			if(func == "lb"){
				if(0<= byt[byt.length()-1]-'0' && byt[byt.length()-1]-'0'<8){
					while(byt.length()<16)  byt.push_back('0');
				}else{
					while(byt.length()<16)  byt.push_back('f');
				}
			}else if(func == "lbu"){
				while(byt.length()<16)  byt.push_back('0');
			}
		}
		reverse(byt.begin(),byt.end());
		regs->at(a).second = "0x";
		regs->at(a).second.append(byt);
		byt.erase();
	}
	}
}
