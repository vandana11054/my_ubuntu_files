

string Sfunc3(string func)
{  //3 bits of func3 appended
    if(func=="sb")
    return "000";
    else if(func=="sh")
    return "001";
    else if(func=="sw")
    return "010";
    else if(func=="sd")
    return "011";
    return "error3"; //Invalid function argument
}
string constant(string imm,string value,string Opcode){
//function to provide a 20 bit binary value for a decimal number(string value)
  int temp = stoi(value); // convert value to integer 
  if((temp>= -2048 && temp<=2047)||(temp>=-4096 && temp<=4094 && Opcode=="1100011" )){
//for B format range of immediate is [-4096,4094] 
//for I,S  formats range of immediate is [-2048,2047]
  if(temp<0){ // if immediate is negative
	bool a= true; 
	// variable that indicates right-most one is met or not for calculating 2's
	// complement in simple method
	temp = 0-temp; //convert imm to positive
	int i=0;
        for(;i<12;i++){ //loop for generating binary equivalent of  +ve decimal number
	  imm.push_back(temp%2 + '0'); 
	  temp = temp/2;
	  if(temp==1){
		  imm.push_back(1+'0');
		  i++;
		  break;
	  }
	}
		  while(i<11){ //if number of bits in immediate's binary form < 12 
			  imm.push_back('0');
			  i++;
		  }
               for(int u=0;u<11;u++){ 
	//loop for calculating 2's complement of a given  binary number
                   if(imm[u]==1+'0'){ //encounter left-most one (still imm. is not reversed)
                            a=false;
			    for(int k=u+1;k<12;k++){ //flip all other bits that are left
               if(imm[k]==0+'0') imm[k]=1+'0'; 
	       else if(imm[k]==1+'0') imm[k]=0+'0';
			    }
		   }
	     if(a==false) break;
	       }
	}
  else{  //if immediate value is positive 
	int i=0;
        for(;i<12;i++){ //loop for generating binary equivalent of  +ve decimal number
	  imm.push_back(temp%2 + '0');
	  temp = temp/2;
	  if(temp==1){
		  imm.push_back(1+'0');
		  i++;
		  break;
	  }
	}
		  while(i<11){ //if number of bits in immediate's binary form < 12
			  imm.push_back(0+'0');
			  i++;
		  }
  }
	reverse(imm.begin(),imm.end());//now reverse string imm to get correct binary value
  return imm;
  }else{
     return "rangeError"; //out_of_range error 
  }
}

string Sformat(string line,string rs1,string rs2,string func,string imm,string in,int i,int count){
	i++;
	for(;i<line.length();i++){
        if(!isspace(line[i]) && line[i]!=','){
 //second argument terminating characters are comma and blank space
                 rs2.push_back(line[i]);
			}
			else if(line[i]==',' ) break;
			}
	string temp;
	i++;
        for(;i<line.length();i++){
        if(((int)line[i] <=57 && (int)line[i] >= 48 && !(isspace(line[i])))||(int)line[i]==45){  // number or minus sign is pushed to temporary string
                  temp.push_back(line[i]);
			}
	else if(line[i]=='(') break;  // stop storing at (
	}
	imm =  constant(imm,temp,Opcode(func)); //binary immediate initialised
        bool next = true;
	i++;
	for(;i<line.length(); i++){
         if(line[i]!=')' && line[i]!='(' && !(isspace(line[i]))){
		// argument of form (arg.) stored in rs1
		 next = false;
		 rs1.push_back(line[i]);
	 }
	 else if(line[i]==')' && !(next)) break; //stop storing at )
	}
        if(imm != "rangeError") {
	       	in.append(imm.substr(0,7)); //imm[11:5]
	}else{
          cout<<"Immediate out of range in line "<<count<<endl;
	  return "1";
	}
        if(reg(rs2)!="invalid") {
	     in.append(reg(rs2));  //append 5 bits of source register
	}else{
             cout<<"Invalid identifier at source register-2 in line "<<count<<endl;
	     return "1"; 
	}
        if(reg(rs1)!="invalid"){
	     in.append(reg(rs1)); //append 5 bits of source register
	}else{
             cout<<"Invalid identifier at source register-1 in line "<<count<<endl;
	     return "1"; 
	}
        if(Sfunc3(func)!="error3") { //3 bits of func3 appended
	    in.append(Sfunc3(func));
	}else{
            cout<<"Suspected syntax error at function in line "<<count<<endl;
	    return "1";
	}
	if(imm != "rangeError")  in.append(imm.substr(7,5));//imm[4:0]
        in.append(Opcode(func));
	return in;
}
