

#include<bits/stdc++.h>
using namespace std;
using namespace std::chrono;

ofstream output("output.txt");
bool valid = true;
set<int> seen;

void check(vector<int> input,int n ,char set,int idx)   //a is pointer to vector of  struct data
{
    bool is_valid = true;
     for( int item : input){
       if(item < 1 || item > n|| seen.count(item)) {
        valid = false;
        is_valid = false;
        break;
       }
       seen.insert(item);
     }  
     if(seen.size() != n){
       is_valid = false;
       valid = false;
     } 
            if(set == 'r') output <<" row "<<(idx+1);
            else if(set == 'c') output <<" column "<<(idx+1);
            else if(set == 'g') output <<" grid "<<(idx+1);
      if(is_valid) {
            output << " and is valid "  <<endl;
      }else output << " and is invalid "<<endl;
      seen.clear();
      return;
}

int main()
{     
    auto start = high_resolution_clock::now();
    int k = 0;
    int n = 0;
    void* ptr;
    ifstream inp("inp.txt");
    string line;
    if(getline(inp,line) && !line.empty()){
        istringstream iss(line);
        iss >> k >> n; 
    }
    
    vector<int> col;
    vector<int> grid;
    vector<vector<int>> sud(n,vector<int>(n));
    
    // input parsing,populating matrix sudoku (sud),row logic
      for(int i=0;i<n;i++){
       if(getline(inp,line)){
          istringstream iss(line); 
                 for(int k = 0; k < n; k++){  //assuming input file is correct n*n
                        iss >> sud[i][k];
                 }  
      }
      }
    inp.close();

    for(int i=0;i<n;i++){
       check(sud[i],n,'r',i);
    }
    
    // column generation and logic
    for(int i = 0; i < n;i++) {
        for( int k=0;k<n;k++){
           col.push_back(sud[k][i]);
        }
      //func call
       check (col,n,'c',i);
       col.clear();
    }
   
    //grid logic
    int idx =0;
    int m = sqrt(n);
        for(int v = 0; v < n ; v = v + m){
        for(int l=0 ; l < n; l = l + m){
        for(int i=0 ; i < m;i++){
          for( int u=0 ; u < m ;u++){ 
             grid.push_back(sud[v+i][l+u]);  
          }
        }
         check (grid,n,'g',idx);
         idx++;
         grid.clear();
       }
    }
    auto stop = high_resolution_clock::now();

      if(valid) {
            output << "Input sudoku is valid "  <<endl;
      }else output << "Input sudoku is invalid "<<endl;
      
      output<<"The total time taken is "<<(duration_cast<microseconds>(stop-start)).count()<<" microseconds."<<endl;
      output.close();
    return 0;
}