

#include<bits/stdc++.h>
using namespace std;
using namespace std::chrono;

ofstream output("output.txt");
bool valid = true;
struct data{
    int num;
    vector<int> row;
    int tid;
    int idx;
    char set;
    bool valid;
};

void * check(void * a)   //a is pointer to vector of  struct data
{
    
    struct data* pr = (struct data*)a;
    set<int> seen;
    pr->valid = true;
     for( int item : pr->row){
       if(item < 1 || item > pr->num || seen.count(item)) {
        valid = false;
        pr->valid = false;
        break;
       }
       seen.insert(item);
    }  
     if(seen.size() != pr->num){
       pr->valid = false;
       valid = false;
     } 
if(pr->set == 'r') output << "Thread "<< (pr->tid )<<" checks row "<<(pr->idx);
else if(pr->set == 'c') output << "Thread "<< (pr->tid )<<" checks column "<<(pr->idx);
else if(pr->set == 'g') output << "Thread "<< (pr->tid )<<" checks grid "<<(pr->idx);
      if(pr->valid) {
            output << " and is valid "  <<endl;
      }else output << " and is invalid "<<endl;
     pthread_exit(NULL);
}

int main()
{    
    ifstream inp("inp.txt");
    int k = 0;
    int n = 0;
    string line;
    if(getline(inp,line) && !line.empty()){
        istringstream iss(line);
        iss >> k >> n; 
    }
    
    int k1 = (k+2)/3; 
    int k2 = (k+1)/3; 
    int k3 = k-k1-k2 ;           
    pthread_t pt1[k1];
    pthread_t pt2[k2];
    pthread_t pt3[k3];
    
    vector<vector<int>> sud(n,vector<int> (n));
    vector< struct data> rowData(n);
    vector< struct data> colData(n);
    vector< struct data> gridData(n);
   
    
    auto start = high_resolution_clock::now();   
    // input parsing,populating matrix sudoku (sud),row logic
    for(int i=0;i<n;i++){
      if(getline(inp,line)){
          istringstream iss(line);
                 for(int k=0;k < n;k++){  //assuming input file is correct n*n
                    iss >> sud[i][k];
                 }  
      }
    }
        inp.close();
        for(int i=0;i<n;i++){
        rowData[i].set = 'r';
        rowData[i].num = n;
        rowData[i].row = sud[i];
        rowData[i].tid = (i%k1)+1;
        rowData[i].idx = i + 1;
        pthread_create(&pt1[i%k1],NULL,&check,&rowData[i]);
        pthread_join(pt1[i%k1],NULL);
       }
   
    // column generation and logic
    for(int i = 0; i < n;i++) {
      vector<int> col;
        for( int k=0;k<n;k++){
           col.push_back(sud[k][i]);
        }
      colData[i].set = 'c';
      colData[i].num = n;
      colData[i].row = col;
      colData[i].tid = k1+(i%k2)+1;
      colData[i].idx = i+1;
      pthread_create(&pt2[i%k2],NULL,&check,&colData[i]);
      pthread_join(pt2[i%k2],NULL);
    }
    
    //grid logic
    int idx =0;
    int m = sqrt(n);
        for(int v = 0; v < n ; v = v + m){
        for(int l=0 ; l < n; l = l + m){
           vector<int> grid;
        for(int i=0 ; i < m ;i++){
          for( int u=0 ; u < m ;u++){ 
                grid.push_back(sud[v+i][l+u]);
          }
        }
       gridData[idx].set = 'g';
       gridData[idx].num = n;
       gridData[idx].row = grid;
       gridData[idx].tid = k1 + k2 + (idx%k3) + 1;
       gridData[idx].idx = idx + 1;
       pthread_create(&pt3[idx%k3],NULL,&check,&gridData[idx]);
       pthread_join(pt3[idx%k3],NULL);
       idx++;
       }
      }

       auto stop = high_resolution_clock::now();

      if(valid) {
            output << "Input sudoku is valid "  <<endl;
      }else output << "Input sudoku is invalid "<<endl;
    
      output<<"The total time taken is "<< duration_cast<microseconds>(stop-start).count() <<" microseconds."<<endl;
      output.close();
    return 0;
}