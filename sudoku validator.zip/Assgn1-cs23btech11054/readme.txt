﻿Contents:
inp.txt
mixed.cpp  named as Assgn1Src-cs23btech11054.cpp
chunk.cpp  named as assgn1Src-cs23btech11054.cpp
seq.cpp    named as assgn1src-cs23btech11054.cpp
output.txt
report.pdf

Input Format:
File name :  inp.txt
Contents:   parameters k,n and suduko in the format:
k n 
[n*n sudoku]
Wrong input handling not supported.

How to run the code:
After providing the input file,
Sequential code: gcc  assgn1src-cs23btech11054.cpp -o a
                 ./a 
Mixed code:   gcc   Assgn1Src-cs23btech11054.cpp  -o a 
                 ./a 
Chunk code :   gcc   assgn1Src-cs23btech11054.cpp -o a 
                 ./a
                 
Output display file:
Output.txt
