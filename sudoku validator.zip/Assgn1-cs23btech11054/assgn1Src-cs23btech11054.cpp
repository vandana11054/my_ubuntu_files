

#include<bits/stdc++.h>
using namespace std;
using namespace std::chrono;

ofstream output("output.txt");
bool valid = true;
struct data{
    int num;
    char set;
    int tid;
    int idx;
    int cs;
    vector<vector<int>> chunk;
    bool valid;
};

void * func(void * a)   //a is pointer to vector of  struct data
{
    struct data* pr = (struct data*) a;
    pr->valid = true;
    for(int l = 0; l < pr->chunk.size();l++){
          set<int> seen;
          bool valid_chunk = true;
            for( int i = 0 ; i < pr->num ;i++){
            if(pr->chunk[l][i] < 1 || pr->chunk[l][i] > pr->num || seen.count(pr->chunk[l][i])) {
                valid_chunk = false;
                valid = false;
                pr->valid = false;
                break;
            }
                seen.insert(pr->chunk[l][i]);
            }
            if(seen.size() != pr->num){
                valid_chunk = false;
                pr->valid = false;
                valid = false;
            } 
       if(pr->set == 'r') output << "Thread "<< (pr->tid)<<" checks row "<<((pr->idx-1)*(pr->cs) + l + 1);
       else if(pr->set == 'c') output << "Thread "<< (pr->tid)<<" checks column "<<((pr->idx-1)*(pr->cs) + l + 1);
       else if(pr->set == 'g') output << "Thread "<< (pr->tid)<<" checks grid "<<((pr->idx-1)*(pr->cs) + l + 1);
       if(valid_chunk) {
            output << " and is valid "  <<endl;
       }else output << " and is invalid "<<endl;   
    }
    pthread_exit(NULL);
}

int main()
{    
    ifstream inp("inp.txt");
    int k=0;
    int n=0;
    string line;
    if(getline(inp,line) && !line.empty()){
        istringstream iss(line);
        if(!(iss >> k >> n)) return 1; 
    }
    int csr = 0;
    int csc = 0;
    int csg = 0;
    int k1 = (k+2)/3;  
    int k2 = (k+1)/3;  
    int k3 = k-k1-k2;             
     csr = (n + k1 -1)/k1;    
     csc = (n + k2 -1)/k2;    
     csg = (n + k3 -1)/k3;    
     vector<pthread_t> rows((max(1,k1)));
     vector<pthread_t> cols((max(1,k2)));
     vector<pthread_t> grids((max(1,k3)));
    vector<vector<int>> sud(n,vector<int> (n));
    vector<struct data> threadData(k1+k2+k3);
     auto start = high_resolution_clock::now();
    // input parsing,populating matrix sudoku (sud),row logic
    for(int i=0;i<n;i++){
       if(getline(inp,line)){
          istringstream iss(line);
                 for(int l = 0;l < n;l++){  //assuming input file is correct n*n
                   iss>> sud[i][l];
                 }  
       }   
    }
 inp.close();
     //row logic and threading
               for(int i=0;i<k1;i++){
                 vector<vector<int>> chunk;
                 for(int m = i*csr; m < min(n,(i+1)*csr);m++){
                    chunk.push_back(sud[m]);
                 }
                    threadData[i].set = 'r';
                    threadData[i].num = n;
                    threadData[i].tid = i+1;
                    threadData[i].idx = i+1;
                    threadData[i].chunk = chunk;
                    threadData[i].cs = csr;
                    pthread_create(&rows[i],NULL,&func,&threadData[i]);
                    pthread_join(rows[i],NULL);
                    }
                
// column generation and logic
                                    
                for( int l = 0; l < k2 ;l++){
                 vector<vector<int>> chunk;
                for( int i = l*csc ;i< min(n,(l+1)*csc); i++){
                   vector<int> col;
                    for(int u =0 ;u < n;u++){
                       col.push_back(sud[u][i]);
                    }
                    chunk.push_back(col);
                }                   
                            threadData[k1+l].set = 'c';
                            threadData[k1+l].num = n;
                            threadData[k1+l].chunk = chunk;
                            threadData[k1+l].cs = csc;
                            threadData[k1+l].tid = l + k1 +1;                
                            threadData[k1+l].idx = l + 1;
                            pthread_create(&cols[l],NULL,&func,&threadData[k1+l]);
                            pthread_join(cols[l],NULL);
                            }
    
    vector<vector<int>> grid;
    //grid logic
    int m = sqrt(n);
        for(int v = 0; v < n ; v = v + m){
          for(int l = 0 ; l < n ;  l = l + m){
            vector<int> elem;
            for(int i=0 ; i<m ;i++){
                    for( int u=0 ; u<m ;u++){ 
                         elem.push_back(sud[v+i][l+u]);
          }
        }
        grid.push_back(elem); 
     }
     }
     
     for(int l = 0 ;l< k3;l++){
         vector<vector<int>> chunk;
     for(int i = l*csg; i < min((int)grid.size(),(l+1)*csg);i++ ){
        chunk.push_back(grid[i]);
     }
      threadData[k1+k2+l].set = 'g';
      threadData[k1+k2+l].num = n;
      threadData[k1+k2+l].chunk = chunk;
      threadData[k1+k2+l].tid = l + k1 + k2 + 1;
      threadData[k1+k2+l].idx = l + 1;
      threadData[k1+k2+l].cs = csg;
      pthread_create(&grids[l],NULL,&func,&threadData[k1+k2+l]);
      pthread_join(grids[l],NULL);
      }

     auto stop  = high_resolution_clock::now(); 
      if(valid) {
             output << "Input sudoku is valid "  <<endl;
       }else output << "Input sudoku is invalid "<<endl;
    
    output<<"The total time taken is "<< duration_cast<microseconds>(stop-start).count() <<" microseconds."<<endl;  
    output.close();
    return 0;
}